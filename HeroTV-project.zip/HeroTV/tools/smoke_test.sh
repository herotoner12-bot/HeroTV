#!/usr/bin/env bash
# Hero TV — automatic smoke test over adb (run from your PC while the TV or an Android TV emulator is connected).
#
#   adb connect <TV-IP>:5555        # TV: Settings > Device Preferences > About > tap Build 7 times,
#                                   #     then Developer options > Network debugging ON
#   ./tools/smoke_test.sh app/build/outputs/apk/debug/app-debug.apk
#
# SAFETY: this script ONLY installs/uninstalls com.herotv.app and sends remote-key events.
# It never touches any other app, system file or system setting.
# It installs the APK on the connected device, so only run it after you approved the build.
set -u
APK="${1:-}"
PKG=com.herotv.app
ACT=$PKG/.MainActivity
PASS=0; FAIL=0
ok()   { echo "  [PASS] $1"; PASS=$((PASS+1)); }
bad()  { echo "  [FAIL] $1"; FAIL=$((FAIL+1)); }
key()  { adb shell input keyevent "$1"; sleep "${2:-0.6}"; }

[ -z "$APK" ] && { echo "usage: $0 path/to/hero-tv.apk"; exit 2; }
adb get-state >/dev/null 2>&1 || { echo "no device connected (adb connect <ip>:5555)"; exit 2; }

echo "== device"; adb shell getprop ro.build.version.release; adb shell getprop ro.product.model
echo "== 0. install (replaces only Hero TV itself)"
adb install -r "$APK" | grep -q Success && ok "installed" || { bad "install failed"; exit 1; }
adb logcat -c

echo "== 1. start: nothing must auto-play, no crash"
adb shell am start -n "$ACT" >/dev/null; sleep 3
adb shell dumpsys activity activities | grep -q "$PKG" && ok "Hero TV is in front" || bad "Hero TV not in front"

echo "== 2. remote keys: all arrows + OK on the home page, then back"
for k in KEYCODE_DPAD_RIGHT KEYCODE_DPAD_LEFT KEYCODE_DPAD_DOWN KEYCODE_DPAD_UP KEYCODE_DPAD_LEFT KEYCODE_DPAD_LEFT; do key $k; done
key KEYCODE_DPAD_DOWN; key KEYCODE_DPAD_DOWN; key KEYCODE_DPAD_CENTER 1.5   # opens "الأفلام" from the side menu
key KEYCODE_BACK 1
adb shell dumpsys activity activities | grep -q "mResumedActivity.*$PKG" && ok "BACK returned to Hero TV page" || bad "BACK left Hero TV unexpectedly"

echo "== 3. visit every side-menu section (DOWN + OK, BACK)"
for i in 1 2 3 4 5 6 7 8 9 10; do
  key KEYCODE_DPAD_DOWN 0.4; key KEYCODE_DPAD_CENTER 1.2
  adb shell dumpsys activity activities | grep -q "mResumedActivity.*$PKG" || { echo "     (left Hero TV at step $i: probably YouTube / settings opened)"; key KEYCODE_BACK 1.5; }
  key KEYCODE_BACK 0.8
done

echo "== 4. crash check"
if adb logcat -d | grep -E "FATAL EXCEPTION|ANR in $PKG" | grep -q .; then
  bad "crash/ANR found:"; adb logcat -d | grep -A12 "FATAL EXCEPTION" | head -40
else ok "no crash / ANR in logcat"; fi

echo "== 5. memory (PSS, KB) — keep this under ~120000 on a <2GB TV"
adb shell dumpsys meminfo $PKG | grep -E "TOTAL PSS|TOTAL:" | head -2
PSS=$(adb shell dumpsys meminfo $PKG | grep -m1 -E "TOTAL" | awk '{print $2}')
[ -n "${PSS:-}" ] && [ "$PSS" -lt 150000 ] 2>/dev/null && ok "PSS=$PSS KB" || bad "PSS=${PSS:-unknown} KB (check manually)"

echo "== 6. no autostart components"
adb shell dumpsys package $PKG | grep -qi "BOOT_COMPLETED" && bad "boot receiver found" || ok "no boot receiver"
adb shell dumpsys package $PKG | grep -q "category.HOME" && bad "HOME category present (could replace the launcher)" || ok "not a HOME launcher"

echo "== 7. the original TV is untouched: default HOME still not Hero TV"
HOME_PKG=$(adb shell cmd package resolve-activity --brief -a android.intent.action.MAIN -c android.intent.category.HOME | tail -1)
echo "     default home: $HOME_PKG"
echo "$HOME_PKG" | grep -q "$PKG" && bad "Hero TV became default home" || ok "default home is still the original launcher"

echo
echo "RESULT: $PASS passed, $FAIL failed"
echo "Manual checks still needed on the real TV: YouTube opens the original app, the TV's own watching app opens,"
echo "Arabic text looks right, simple mode, settings survive a reboot (see TEST_REPORT_AR.md)."
[ "$FAIL" -eq 0 ]
