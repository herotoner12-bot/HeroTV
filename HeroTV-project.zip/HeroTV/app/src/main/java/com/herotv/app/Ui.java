package com.herotv.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.DisplayMetrics;
import android.util.LruCache;
import android.util.TypedValue;
import android.view.Gravity;
import android.widget.TextView;

import java.io.File;

/**
 * Look & feel helpers. All sizes are given in "design pixels" for a 1920x1080 screen and are
 * scaled to the real TV resolution (720p / 1080p / 4K) by {@link #px(float)}.
 */
final class Ui {
    private Ui() {}

    // palette: dark + purple + blue
    static final int PURPLE = 0xFF7C3AED, PURPLE_D = 0xFF4C1D95, PURPLE_L = 0xFFB794FF;
    static final int BLUE = 0xFF2563EB, BLUE_D = 0xFF1E3A8A;
    static final int WHITE = 0xFFFFFFFF, TEXT2 = 0xFFD6D0F5, MUTED = 0xFFA39DCB;
    static final int GLASS = 0x2EFFFFFF, GLASS_HI = 0x40FFFFFF;
    static final int YT_RED = 0xFFFF1F1F;

    /** Minimum text size (design px). The brief: never use small text. */
    static final float MIN_TEXT = 28f;

    private static float scale = 1f;
    private static float fontMul = 1f;

    static void init(Context c) {
        DisplayMetrics dm = c.getResources().getDisplayMetrics();
        scale = Math.max(dm.widthPixels, dm.heightPixels) / 1920f;
        refresh();
    }

    /** Call after any change of simple mode / font level. */
    static void refresh() {
        if (Prefs.simpleMode()) {
            fontMul = 1.35f;
        } else {
            int l = Prefs.fontLevel();
            fontMul = l == 1 ? 1.15f : l == 2 ? 1.3f : 1f;
        }
    }

    static boolean simple() { return Prefs.simpleMode(); }

    static int px(float designPx) { return Math.round(designPx * scale); }

    static TextView text(Context c, String s, float size, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextColor(color);
        t.setTextSize(TypedValue.COMPLEX_UNIT_PX, px(Math.max(MIN_TEXT, size) * fontMul));
        t.setTypeface(bold ? Typeface.DEFAULT_BOLD : Typeface.DEFAULT);
        t.setIncludeFontPadding(false);
        t.setGravity(Gravity.CENTER_VERTICAL | Gravity.START); // START = right edge in RTL
        return t;
    }

    static GradientDrawable box(int fill, float radius, int stroke, float strokeW) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(px(radius));
        if (strokeW > 0) g.setStroke(Math.max(1, px(strokeW)), stroke);
        return g;
    }

    static GradientDrawable grad(int c1, int c2, float radius) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{c1, c2});
        g.setCornerRadius(px(radius));
        return g;
    }

    private static final int[][] CARD_COLORS = {
            {0xFF5B21B6, 0xFF1E1B4B}, {0xFF1D4ED8, 0xFF1E1B4B}, {0xFF9D174D, 0xFF2E1065},
            {0xFF0F766E, 0xFF1E1B4B}, {0xFFB45309, 0xFF3B0764}, {0xFF4338CA, 0xFF0F172A}
    };

    static int[] cardColors(String key) {
        return CARD_COLORS[(key.hashCode() & 0x7fffffff) % CARD_COLORS.length];
    }

    // ------------------------------------------------------------------ optional user posters

    private static final LruCache<String, Bitmap> POSTERS = new LruCache<String, Bitmap>(6 * 1024 * 1024) {
        @Override
        protected int sizeOf(String key, Bitmap b) { return b.getByteCount(); }
    };

    /**
     * Optional artwork. If the user copies an image named like the card title (e.g. "باب الحارة.jpg")
     * or "hero.jpg" into  Android/data/com.herotv.app/files/posters/  it is shown on the card.
     * No artwork is bundled (copyright). Images are down-sampled and cached (max 6 MB) to protect RAM.
     */
    static Bitmap poster(Context c, int w, int h, String... keys) {
        File dir = c.getExternalFilesDir("posters");
        if (dir == null || !dir.isDirectory()) return null;
        String[] exts = {"jpg", "jpeg", "png", "webp"};
        for (String k : keys) {
            for (String e : exts) {
                File f = new File(dir, k + "." + e);
                if (!f.isFile()) continue;
                String ck = f.getAbsolutePath() + "@" + w;
                Bitmap cached = POSTERS.get(ck);
                if (cached != null) return cached;
                try {
                    BitmapFactory.Options o = new BitmapFactory.Options();
                    o.inJustDecodeBounds = true;
                    BitmapFactory.decodeFile(f.getAbsolutePath(), o);
                    int s = 1;
                    while (o.outWidth / (s * 2) >= w && o.outHeight / (s * 2) >= h) s *= 2;
                    o.inJustDecodeBounds = false;
                    o.inSampleSize = s;
                    o.inPreferredConfig = Bitmap.Config.RGB_565;
                    Bitmap b = BitmapFactory.decodeFile(f.getAbsolutePath(), o);
                    if (b != null) {
                        POSTERS.put(ck, b);
                        return b;
                    }
                } catch (Throwable ignored) { /* bad image or low memory: just skip it */ }
            }
        }
        return null;
    }
}
