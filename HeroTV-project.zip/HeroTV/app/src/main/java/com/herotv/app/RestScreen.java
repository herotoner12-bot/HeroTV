package com.herotv.app;

import android.content.Context;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * وضع الاستراحة: a calm mountain scene with the clock. Any remote key returns (see MainActivity).
 * Static drawing, the clock moves a little every minute (protects OLED/LED panels from burn-in),
 * nothing plays, nothing is downloaded.
 */
final class RestScreen extends Screen {

    RestScreen(MainActivity a) { super(a); }

    @Override
    View build() {
        Context c = act;
        FrameLayout f = new FrameLayout(c);
        f.setClipChildren(false);
        f.addView(new BackgroundView(c, 2, false), new FrameLayout.LayoutParams(Parts.MATCH, Parts.MATCH));

        f.addView(new DriftingClock(c), new FrameLayout.LayoutParams(Parts.WRAP, Parts.WRAP, Gravity.LEFT | Gravity.TOP));

        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Parts.WRAP, Parts.WRAP, Gravity.RIGHT | Gravity.TOP);
        lp.setMargins(Ui.px(60), Ui.px(50), Ui.px(60), 0);
        f.addView(new LogoView(c, 84), lp);

        TextView hello = Ui.text(c, "♥  استمتع بمشاهدة ممتعة", 40, Ui.WHITE, true);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(Parts.WRAP, Parts.WRAP, Gravity.RIGHT | Gravity.BOTTOM);
        hp.setMargins(Ui.px(60), 0, Ui.px(60), Ui.px(60));
        f.addView(hello, hp);

        TextView back = Ui.text(c, "اضغط أي زر في الريموت للعودة", 32, Ui.TEXT2, false);
        FrameLayout.LayoutParams bp = new FrameLayout.LayoutParams(Parts.WRAP, Parts.WRAP, Gravity.LEFT | Gravity.BOTTOM);
        bp.setMargins(Ui.px(60), 0, Ui.px(60), Ui.px(60));
        f.addView(back, bp);
        return f;
    }

    /** Big clock + date that hops to a new corner-ish position once a minute. */
    private static final class DriftingClock extends LinearLayout {
        private final android.os.Handler h = new android.os.Handler(android.os.Looper.getMainLooper());
        private int step;
        private boolean running;
        private final Runnable move = new Runnable() {
            @Override
            public void run() {
                if (!running) return;
                step = (step + 1) % 4;
                place();
                h.postDelayed(this, 60000);
            }
        };

        DriftingClock(Context c) {
            super(c);
            setOrientation(VERTICAL);
            setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
            addView(TickText.clock(c, false, 120, Ui.WHITE, true), new LayoutParams(Parts.WRAP, Parts.WRAP));
            addView(TickText.clock(c, true, 44, Ui.TEXT2, false), new LayoutParams(Parts.WRAP, Parts.WRAP));
            place();
        }

        private void place() {
            int[][] pos = {{60, 50}, {120, 110}, {60, 170}, {0, 100}};
            setTranslationX(Ui.px(pos[step][0]));
            setTranslationY(Ui.px(pos[step][1]));
        }

        @Override protected void onAttachedToWindow() {
            super.onAttachedToWindow();
            running = true;
            h.postDelayed(move, 60000);
        }

        @Override protected void onDetachedFromWindow() {
            running = false;
            h.removeCallbacks(move);
            super.onDetachedFromWindow();
        }
    }
}
