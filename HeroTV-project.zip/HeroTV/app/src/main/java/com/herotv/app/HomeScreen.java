package com.herotv.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

/** The main page, following the reference design: side menu, hero, featured sections, apps, bottom panels. */
final class HomeScreen extends Screen {

    HomeScreen(MainActivity a) { super(a); }

    @Override
    View build() {
        final Context c = act;
        FrameLayout root = new FrameLayout(c);
        root.setClipChildren(false);

        int sideW = Ui.px(280);
        root.addView(sidebar(), new FrameLayout.LayoutParams(sideW, Parts.MATCH, Gravity.LEFT));

        LinearLayout col = Parts.vcol(c);
        col.setPadding(Ui.px(36), Ui.px(14), Ui.px(36), Ui.px(40));

        col.addView(Parts.topBar(act, true), Parts.lp(Parts.MATCH, Ui.px(110), 0, 0, 0, 0, Ui.px(10)));
        col.addView(hero(), Parts.lp(Parts.MATCH, Ui.px(240), 0, 0, 0, 0, Ui.px(18)));

        col.addView(Parts.sectionTitle(c, "أقسام مميزة"), Parts.lp(Parts.MATCH, Parts.WRAP, 0, 0, 0, 0, Ui.px(8)));
        col.addView(featuredRow(), Parts.lp(Parts.MATCH, Ui.px(200), 0, 0, 0, 0, Ui.px(14)));

        col.addView(Parts.sectionTitle(c, "تطبيقاتي"), Parts.lp(Parts.MATCH, Parts.WRAP, 0, 0, 0, 0, Ui.px(8)));
        col.addView(appsRow(), Parts.lp(Parts.MATCH, Ui.px(190), 0, 0, 0, 0, Ui.px(14)));

        col.addView(bottomRow(), Parts.lp(Parts.MATCH, Ui.px(210), 0, 0, 0, 0, 0));

        ScrollView sv = Parts.scroll(c, col);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(Parts.MATCH, Parts.MATCH);
        cp.leftMargin = sideW;
        root.addView(sv, cp);
        return root;
    }

    // ------------------------------------------------------------------ side menu

    private View sidebar() {
        LinearLayout s = Parts.vcol(act);
        s.setBackground(Ui.box(0x99060512, 0, 0, 0));
        s.setPadding(Ui.px(16), Ui.px(24), Ui.px(16), Ui.px(16));

        s.addView(nav("🏠", "الرئيسية", true, false, null));
        s.addView(nav("▶", "YouTube", false, true, new Runnable() {
            @Override public void run() { Launcher.openYouTube(act, null); }
        }));
        s.addView(nav("🎬", "الأفلام", false, false, go(MainActivity.Dest.MOVIES)));
        s.addView(nav("📺", "المسلسلات", false, false, go(MainActivity.Dest.SERIES)));
        s.addView(nav("📡", "القنوات", false, false, go(MainActivity.Dest.CHANNELS)));
        s.addView(nav("⊞", "التطبيقات", false, false, go(MainActivity.Dest.APPS)));
        s.addView(nav("⭐", "المفضلة", false, false, go(MainActivity.Dest.FAVORITES)));
        s.addView(nav("🕒", "أكمل المشاهدة", false, false, go(MainActivity.Dest.CONTINUE)));
        s.addView(nav("👑", "عالم أخي ♥", false, false, go(MainActivity.Dest.BROTHER)));
        s.addView(nav("👥", "الملفات الشخصية", false, false, go(MainActivity.Dest.PROFILES)));
        s.addView(nav("⚙", "الإعدادات", false, false, go(MainActivity.Dest.SETTINGS)));
        s.addView(nav("🌙", "وضع الاستراحة", false, false, go(MainActivity.Dest.REST)));
        return s;
    }

    private Runnable go(final MainActivity.Dest d) {
        return new Runnable() {
            @Override public void run() { act.go(d, null); }
        };
    }

    private View nav(String glyph, String label, boolean selected, boolean youtube, final Runnable action) {
        FocusCard c = selected ? new FocusCard(act, Ui.PURPLE, 0xFF4F46E5, 22)
                : new FocusCard(act, 0x00FFFFFF, 0x00FFFFFF, 22);
        if (youtube) c.accent(0x99FF2A2A, 2).rimColor(0xFFFF6B6B);
        LinearLayout r = new LinearLayout(act);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        r.setGravity(Gravity.CENTER_VERTICAL);
        TextView g = Ui.text(act, glyph, 34, youtube ? Ui.YT_RED : Ui.WHITE, false);
        g.setGravity(Gravity.CENTER);
        r.addView(g, new LinearLayout.LayoutParams(Ui.px(64), Parts.WRAP));
        TextView t = Ui.text(act, label, 30, Ui.WHITE, selected || youtube);
        t.setGravity(Gravity.RIGHT | Gravity.CENTER_VERTICAL);
        t.setSingleLine(true);
        r.addView(t, new LinearLayout.LayoutParams(0, Parts.WRAP, 1f));
        r.setPadding(Ui.px(8), 0, Ui.px(18), 0);
        c.addView(r, new FrameLayout.LayoutParams(Parts.MATCH, Parts.MATCH));
        if (action != null) {
            c.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { action.run(); }
            });
        }
        return wrapNav(c);
    }

    private View wrapNav(View c) {
        FrameLayout f = new FrameLayout(act);
        f.setClipChildren(false);
        f.addView(c, new FrameLayout.LayoutParams(Parts.MATCH, Parts.MATCH));
        f.setLayoutParams(Parts.lp(Parts.MATCH, Ui.px(68), 0, 0, Ui.px(3), 0, Ui.px(3)));
        return f;
    }

    // ------------------------------------------------------------------ hero

    private View hero() {
        FocusCard h = new FocusCard(act, 0xFF3B1D8F, 0xFF0B1A4A, 32).plain();
        Bitmap bmp = Ui.poster(act, Ui.px(1500), Ui.px(240), "hero");
        if (bmp != null) {
            ImageView iv = new ImageView(act);
            iv.setImageBitmap(bmp);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            h.addView(iv, new FrameLayout.LayoutParams(Parts.MATCH, Parts.MATCH));
            View shade = new View(act);
            shade.setBackgroundColor(0x66000000);
            h.addView(shade, new FrameLayout.LayoutParams(Parts.MATCH, Parts.MATCH));
        }
        LinearLayout t = Parts.vcol(act);
        t.setPadding(Ui.px(48), Ui.px(20), Ui.px(48), Ui.px(20));
        t.setGravity(Gravity.CENTER_VERTICAL);
        TextView hi = Ui.text(act, "أهلاً " + Prefs.activeProfileObj().name + "، أهلاً بك في", 40, Ui.WHITE, false);
        t.addView(hi, new LinearLayout.LayoutParams(Parts.MATCH, Parts.WRAP));
        TextView name = Ui.text(act, "Hero TV", 88, Ui.WHITE, true);
        name.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        t.addView(name, new LinearLayout.LayoutParams(Parts.MATCH, Parts.WRAP));
        TextView sub = Ui.text(act, "استمتع بمشاهدة ممتعة ♥", 38, Ui.PURPLE_L, true);
        t.addView(sub, new LinearLayout.LayoutParams(Parts.MATCH, Parts.WRAP));
        h.addView(t, new FrameLayout.LayoutParams(Parts.MATCH, Parts.MATCH));
        return h;
    }

    // ------------------------------------------------------------------ featured sections

    private View featuredRow() {
        LinearLayout row = Parts.hrow(act, 6);
        row.addView(feat("🎖", "أفلام حربية", 0xFF7C2D12, 0xFF1C1917, MainActivity.Dest.MOVIES, "حروب"));
        row.addView(feat("🏛", "أفلام تاريخية", 0xFF92400E, 0xFF1E1B4B, MainActivity.Dest.MOVIES, "تاريخي"));
        row.addView(feat("🎞", "أفلام كردية", 0xFF166534, 0xFF7F1D1D, MainActivity.Dest.MOVIES, "كردية"));
        row.addView(feat("🐺", "وادي الذئاب", 0xFF1E3A8A, 0xFF0F172A, MainActivity.Dest.BROTHER, "وادي الذئاب"));
        row.addView(feat("📺", "مسلسلات عربية", 0xFF9D174D, 0xFF3B0764, MainActivity.Dest.SERIES, "عربية"));
        row.addView(feat("🎮", "كرتون وأنمي", 0xFF1D4ED8, 0xFF7C3AED, MainActivity.Dest.MOVIES, "كرتون"));
        return row;
    }

    private View feat(String glyph, String title, int c1, int c2, final MainActivity.Dest d, final String arg) {
        FocusCard c = Parts.iconCard(act, glyph, title, null, c1, c2, 64);
        c.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { act.go(d, arg); }
        });
        c.setLayoutParams(Parts.lp(0, Parts.MATCH, 1f, Ui.px(8), Ui.px(8), Ui.px(8), Ui.px(8)));
        return c;
    }

    // ------------------------------------------------------------------ apps row (YouTube first!)

    private View appsRow() {
        LinearLayout row = Parts.hrow(act, 7);
        int g = Ui.px(8);

        FocusCard yt = Parts.youtubeCard(act, 36, false);
        row.addView(yt, Parts.lp(0, Parts.MATCH, 2f, g, g, g, g));
        firstFocus = yt;                                   // YouTube is focused when Hero TV opens

        String orig = Prefs.originalApp();
        Apps.AppInfo origApp = Apps.find(act, orig);
        if (origApp != null) {
            row.addView(Parts.appCard(act, origApp), Parts.lp(0, Parts.MATCH, 1f, g, g, g, g));
        } else {
            FocusCard pick = Parts.addCard(act, "تلفزيوننا");
            pick.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { act.go(MainActivity.Dest.PICK_ORIGINAL, null); }
            });
            row.addView(pick, Parts.lp(0, Parts.MATCH, 1f, g, g, g, g));
        }

        List<Apps.AppInfo> pop = Apps.popularInstalled(act, 3, orig);
        for (Apps.AppInfo a : pop) row.addView(Parts.appCard(act, a), Parts.lp(0, Parts.MATCH, 1f, g, g, g, g));

        FocusCard all = Parts.iconCard(act, "⊞", "كل التطبيقات", null, 0xFF312E81, 0xFF1E1B4B, 60);
        all.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { act.go(MainActivity.Dest.APPS, null); }
        });
        row.addView(all, Parts.lp(0, Parts.MATCH, 1f, g, g, g, g));
        return row;
    }

    // ------------------------------------------------------------------ bottom panels

    private View bottomRow() {
        LinearLayout row = Parts.hrow(act, 3);
        int g = Ui.px(8);

        // continue watching
        List<String> rec = Prefs.recents();
        Catalog.Item last = rec.isEmpty() ? null : Catalog.byId(rec.get(0));
        FocusCard cont = panel("🕒", "أكمل المشاهدة",
                last == null ? "لم تفتح شيئاً بعد" : "آخر ما فتحته:\n" + last.title,
                MainActivity.Dest.CONTINUE);
        row.addView(cont, Parts.lp(0, Parts.MATCH, 1f, g, g, g, g));

        // profiles
        StringBuilder names = new StringBuilder();
        for (Prefs.Profile p : Prefs.profiles()) {
            if (names.length() > 0) names.append("   ");
            names.append(p.glyph).append(' ').append(p.name);
        }
        FocusCard prof = panel("👥", "ملفات العائلة", names.toString(), MainActivity.Dest.PROFILES);
        row.addView(prof, Parts.lp(0, Parts.MATCH, 1f, g, g, g, g));

        // rest mode
        FocusCard rest = panel("🌙", "وضع الاستراحة", "صور هادئة مع الساعة\nاضغط OK للتفعيل", MainActivity.Dest.REST);
        row.addView(rest, Parts.lp(0, Parts.MATCH, 1f, g, g, g, g));
        return row;
    }

    private FocusCard panel(String glyph, String title, String body, final MainActivity.Dest d) {
        FocusCard p = new FocusCard(act, 0x33FFFFFF, 0x1AFFFFFF, 30);
        LinearLayout v = Parts.vcol(act);
        v.setPadding(Ui.px(28), Ui.px(20), Ui.px(28), Ui.px(16));
        TextView t = Ui.text(act, glyph + "  " + title, 38, Ui.WHITE, true);
        v.addView(t, new LinearLayout.LayoutParams(Parts.MATCH, Parts.WRAP));
        TextView b = Ui.text(act, body, 30, Ui.TEXT2, false);
        b.setMaxLines(3);
        b.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(Parts.MATCH, Parts.WRAP);
        bp.topMargin = Ui.px(14);
        v.addView(b, bp);
        p.addView(v, new FrameLayout.LayoutParams(Parts.MATCH, Parts.MATCH));
        p.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View x) { act.go(d, null); }
        });
        return p;
    }
}
