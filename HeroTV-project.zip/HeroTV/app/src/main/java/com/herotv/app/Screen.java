package com.herotv.app;

import android.view.View;

/** One page of the app. {@link #build()} creates the whole view tree; navigation lives in MainActivity. */
abstract class Screen {
    final MainActivity act;
    /** The view that receives the remote's focus when the page opens (may be null). */
    View firstFocus;

    Screen(MainActivity a) { act = a; }

    abstract View build();
}
