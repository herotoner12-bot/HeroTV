package com.herotv.app;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;

/**
 * The browsable content. IMPORTANT: Hero TV does not host or stream anything. Every item is a
 * SHORTCUT that opens the ORIGINAL installed YouTube app on a search for {@link Item#query}.
 * The family can add / delete their own shortcuts (stored in Prefs).
 */
final class Catalog {
    private Catalog() {}

    static final int MOVIE = 0, SERIES = 1, CHANNEL = 2, BROTHER = 3;

    static final class Item {
        final String id, group, title, query;
        final int section;
        final boolean custom;

        Item(String id, int section, String group, String title, String query, boolean custom) {
            this.id = id; this.section = section; this.group = group;
            this.title = title; this.query = query; this.custom = custom;
        }
    }

    private static List<Item> cache;

    static synchronized List<Item> all() {
        if (cache == null) {
            cache = new ArrayList<>();
            seed();
            loadCustom();
        }
        return cache;
    }

    static List<Item> inSection(int section) {
        List<Item> l = new ArrayList<>();
        for (Item i : all()) if (i.section == section) l.add(i);
        return l;
    }

    static List<String> groups(int section) {
        LinkedHashSet<String> s = new LinkedHashSet<>();
        for (Item i : all()) if (i.section == section) s.add(i.group);
        return new ArrayList<>(s);
    }

    static Item byId(String id) {
        for (Item i : all()) if (i.id.equals(id)) return i;
        return null;
    }

    static synchronized Item addCustom(int section, String group, String title, String query) {
        Item it = new Item("c_" + System.currentTimeMillis(), section, group, title, query, true);
        all().add(it);
        saveCustom();
        return it;
    }

    static synchronized void deleteCustom(String id) {
        for (int i = 0; i < all().size(); i++) {
            Item it = all().get(i);
            if (it.custom && it.id.equals(id)) {
                all().remove(i);
                break;
            }
        }
        saveCustom();
    }

    // ------------------------------------------------------------------ persistence of custom items

    private static void saveCustom() {
        JSONArray a = new JSONArray();
        for (Item i : cache) {
            if (!i.custom) continue;
            try {
                a.put(new JSONObject().put("id", i.id).put("s", i.section).put("g", i.group)
                        .put("t", i.title).put("q", i.query));
            } catch (JSONException ignored) { }
        }
        Prefs.putString("custom_items", a.toString());
    }

    private static void loadCustom() {
        try {
            JSONArray a = new JSONArray(Prefs.getString("custom_items", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                cache.add(new Item(o.getString("id"), o.getInt("s"), o.getString("g"),
                        o.getString("t"), o.getString("q"), true));
            }
        } catch (JSONException ignored) { }
    }

    // ------------------------------------------------------------------ built-in shortcuts

    private static void add(int section, String group, String title, String query) {
        String id = section + "_" + Integer.toHexString((group + "|" + title).hashCode());
        cache.add(new Item(id, section, group, title, query, false));
    }

    private static void seed() {
        // ---- الأفلام
        add(MOVIE, "أكشن", "أفلام أكشن", "أفلام أكشن");
        add(MOVIE, "أكشن", "أفلام مطاردات", "أفلام مطاردات وأكشن");
        add(MOVIE, "حروب", "أفلام حربية", "أفلام حربية");
        add(MOVIE, "حروب", "أفلام الحرب العالمية", "أفلام الحرب العالمية");
        add(MOVIE, "تاريخي", "أفلام تاريخية", "أفلام تاريخية");
        add(MOVIE, "تاريخي", "أفلام ملحمية", "أفلام ملحمية");
        add(MOVIE, "كوميديا", "أفلام كوميدية", "أفلام كوميدية");
        add(MOVIE, "كوميديا", "كوميديا عربية", "أفلام كوميديا عربية");
        add(MOVIE, "دراما", "أفلام دراما", "أفلام دراما");
        add(MOVIE, "دراما", "أفلام عربية قديمة", "أفلام عربية قديمة");
        add(MOVIE, "كردية", "أفلام كردية", "أفلام كردية");
        add(MOVIE, "كردية", "فيلم كردي مترجم", "فيلم كردي مترجم");
        add(MOVIE, "وثائقي", "أفلام وثائقية", "أفلام وثائقية");
        add(MOVIE, "وثائقي", "عالم الطبيعة", "وثائقي طبيعة");
        add(MOVIE, "كرتون", "أفلام كرتون", "أفلام كرتون");
        add(MOVIE, "كرتون", "أفلام الأطفال", "أفلام الأطفال");

        // ---- المسلسلات
        add(SERIES, "عربية", "مسلسلات عربية", "مسلسلات عربية");
        add(SERIES, "عربية", "مسلسلات سورية", "مسلسلات سورية");
        add(SERIES, "عربية", "مسلسلات مصرية", "مسلسلات مصرية");
        add(SERIES, "تاريخية", "مسلسلات تاريخية", "مسلسلات تاريخية");
        add(SERIES, "تاريخية", "البيئة الشامية", "مسلسلات البيئة الشامية");
        add(SERIES, "تركية", "مسلسلات تركية", "مسلسلات تركية مدبلجة");
        add(SERIES, "تركية", "مسلسلات تركية مترجمة", "مسلسلات تركية مترجمة");
        add(SERIES, "كردية", "مسلسلات كردية", "مسلسلات كردية");
        add(SERIES, "كرتون", "مسلسلات كرتون", "مسلسلات كرتون");
        add(SERIES, "كرتون", "أنمي", "أنمي مدبلج");

        // ---- القنوات (بث مباشر عبر YouTube)
        add(CHANNEL, "أخبار", "الجزيرة", "قناة الجزيرة بث مباشر");
        add(CHANNEL, "أخبار", "العربية", "قناة العربية بث مباشر");
        add(CHANNEL, "أخبار", "سكاي نيوز عربية", "سكاي نيوز عربية بث مباشر");
        add(CHANNEL, "أخبار", "BBC عربي", "BBC News عربي بث مباشر");
        add(CHANNEL, "أخبار", "فرانس 24", "فرانس 24 بالعربية بث مباشر");
        add(CHANNEL, "أخبار", "DW عربية", "DW عربية بث مباشر");
        add(CHANNEL, "أخبار", "TRT عربي", "TRT عربي بث مباشر");
        add(CHANNEL, "كردية", "Kurdistan24", "Kurdistan24 بث مباشر");
        add(CHANNEL, "كردية", "Rudaw", "Rudaw بث مباشر");

        // ---- عالم أخي
        add(BROTHER, "باب الحارة", "باب الحارة — الحلقات", "باب الحارة الحلقات");
        add(BROTHER, "باب الحارة", "باب الحارة — الجزء الأول", "باب الحارة الجزء الأول");
        add(BROTHER, "باب الحارة", "باب الحارة — الجزء الثاني", "باب الحارة الجزء الثاني");
        add(BROTHER, "وادي الذئاب", "وادي الذئاب — الحلقات", "وادي الذئاب الحلقات");
        add(BROTHER, "وادي الذئاب", "وادي الذئاب — الموسم الأول", "وادي الذئاب الموسم الأول");
        add(BROTHER, "وادي الذئاب", "وادي الذئاب — مشاهد", "وادي الذئاب أفضل المشاهد");
        add(BROTHER, "المسلسلات العربية", "مسلسلات عربية", "مسلسلات عربية");
        add(BROTHER, "المسلسلات العربية", "مسلسلات سورية", "مسلسلات سورية");
        add(BROTHER, "المسلسلات العربية", "مسلسلات تاريخية", "مسلسلات تاريخية");
        add(BROTHER, "الأفلام الكردية", "أفلام كردية", "أفلام كردية");
        add(BROTHER, "الأفلام الكردية", "فيلم كردي مترجم", "فيلم كردي مترجم");
        add(BROTHER, "الأفلام الكردية", "أفلام كردية حربية", "فيلم كردي حربي");
        add(BROTHER, "الأفلام الحربية", "أفلام حربية", "أفلام حربية");
        add(BROTHER, "الأفلام الحربية", "أفلام الحرب العالمية", "أفلام الحرب العالمية");
        add(BROTHER, "الأفلام الحربية", "أفلام حروب حديثة", "أفلام حروب حديثة");
    }
}
