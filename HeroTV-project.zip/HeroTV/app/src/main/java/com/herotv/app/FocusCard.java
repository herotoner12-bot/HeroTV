package com.herotv.app;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Outline;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.LayerDrawable;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;

/**
 * The one focusable building block of the whole UI: a rounded card that shows a glowing frame
 * and a short zoom when the remote's focus is on it. D-pad OK = click, long OK = long click.
 * No continuous animation => light on a <2 GB TV.
 */
final class FocusCard extends FrameLayout {
    private final float radiusPx;
    private final GradientDrawable bg;
    private Drawable rim, accent;
    private int rimColor = 0xFFB794FF;

    FocusCard(Context c, int c1, int c2, float radiusDesignPx) {
        super(c);
        radiusPx = Ui.px(radiusDesignPx);
        bg = Ui.grad(c1, c2, radiusDesignPx);
        setBackground(bg);
        setFocusable(true);
        setClickable(true);
        setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radiusPx);
            }
        });
        setClipToOutline(true);
    }

    /** A non-interactive panel with the same look. */
    FocusCard plain() {
        setFocusable(false);
        setClickable(false);
        return this;
    }

    void fill(int c1, int c2) { bg.setColors(new int[]{c1, c2}); invalidate(); }

    /** Permanent thin coloured frame (used to make YouTube stand out even when not focused). */
    FocusCard accent(int color, float widthDesignPx) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(Color.TRANSPARENT);
        g.setCornerRadius(radiusPx);
        g.setStroke(Math.max(2, Ui.px(widthDesignPx)), color);
        accent = g;
        setForeground(accent);
        return this;
    }

    FocusCard rimColor(int color) {
        rimColor = color;
        rim = null;
        return this;
    }

    private Drawable rim() {
        if (rim == null) {
            GradientDrawable glow = new GradientDrawable();
            glow.setColor(Color.TRANSPARENT);
            glow.setCornerRadius(radiusPx);
            glow.setStroke(Ui.px(16), (rimColor & 0x00FFFFFF) | 0x66000000);
            GradientDrawable edge = new GradientDrawable();
            edge.setColor(Color.TRANSPARENT);
            edge.setCornerRadius(radiusPx);
            edge.setStroke(Ui.px(6), 0xFFEFE6FF);
            rim = new LayerDrawable(new Drawable[]{glow, edge});
        }
        return rim;
    }

    @Override
    protected void onFocusChanged(boolean gained, int direction, Rect previouslyFocusedRect) {
        super.onFocusChanged(gained, direction, previouslyFocusedRect);
        setForeground(gained ? rim() : accent);
        setTranslationZ(gained ? Ui.px(12) : 0);
        float s = gained ? 1.07f : 1f;
        animate().cancel();
        animate().scaleX(s).scaleY(s).setDuration(120).start();
    }
}
