package com.herotv.app;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.List;

/** Shared UI pieces so every section looks the same (header, cards, grids, top bar...). */
final class Parts {
    private Parts() {}

    static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    // ------------------------------------------------------------------ layout helpers

    static LinearLayout.LayoutParams lp(int w, int h, float weight, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.setMargins(l, t, r, b);
        return p;
    }

    /** Horizontal row laid out right-to-left (first child = right edge). */
    static LinearLayout hrow(Context c, float weightSum) {
        LinearLayout r = new LinearLayout(c);
        r.setOrientation(LinearLayout.HORIZONTAL);
        r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        r.setClipChildren(false);
        r.setClipToPadding(false);
        if (weightSum > 0) r.setWeightSum(weightSum);
        return r;
    }

    static LinearLayout vcol(Context c) {
        LinearLayout v = new LinearLayout(c);
        v.setOrientation(LinearLayout.VERTICAL);
        v.setClipChildren(false);
        v.setClipToPadding(false);
        return v;
    }

    static ScrollView scroll(Context c, View content) {
        ScrollView s = new ScrollView(c);
        s.setVerticalScrollBarEnabled(false);
        s.setClipChildren(false);
        s.setClipToPadding(false);
        s.setOverScrollMode(View.OVER_SCROLL_NEVER);
        s.setFillViewport(true);
        s.addView(content, new ScrollView.LayoutParams(MATCH, WRAP));
        return s;
    }

    /** Rows of equal cards, right-to-left, `cols` per row. Missing cells are empty spacers. */
    static LinearLayout grid(Context c, List<View> cards, int cols, int cardH) {
        LinearLayout col = vcol(c);
        int g = Ui.px(10);
        for (int i = 0; i < cards.size(); i += cols) {
            LinearLayout row = hrow(c, 0);
            for (int j = 0; j < cols; j++) {
                int k = i + j;
                View v = k < cards.size() ? cards.get(k) : new View(c);
                row.addView(v, lp(0, cardH, 1f, g, g, g, g));
            }
            col.addView(row, new LinearLayout.LayoutParams(MATCH, WRAP));
        }
        return col;
    }

    static View sectionTitle(Context c, String s) {
        LinearLayout r = new LinearLayout(c);
        r.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        r.setGravity(Gravity.CENTER_VERTICAL);
        View bar = new View(c);
        bar.setBackground(Ui.box(Ui.PURPLE_L, 4, 0, 0));
        r.addView(bar, new LinearLayout.LayoutParams(Ui.px(8), Ui.px(40)));
        TextView t = Ui.text(c, s, 38, Ui.WHITE, true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(WRAP, WRAP);
        lp.setMarginStart(Ui.px(14));
        r.addView(t, lp);
        return r;
    }

    static TextView centerMessage(Context c, String s) {
        TextView t = Ui.text(c, s, 40, Ui.TEXT2, false);
        t.setGravity(Gravity.CENTER);
        t.setLineSpacing(0, 1.3f);
        return t;
    }

    // ------------------------------------------------------------------ header / top bar

    /** Back chevron + title on the left, Hero TV logo on the right (as in the reference design). */
    static View header(final MainActivity a, String glyph, String title) {
        FrameLayout f = new FrameLayout(a);
        f.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        f.setClipChildren(false);

        LinearLayout left = new LinearLayout(a);
        left.setOrientation(LinearLayout.HORIZONTAL);
        left.setGravity(Gravity.CENTER_VERTICAL);
        left.setClipChildren(false);

        FocusCard back = new FocusCard(a, Ui.GLASS, Ui.GLASS, 24);
        back.setTag("back");
        TextView chev = Ui.text(a, "‹", 64, Ui.WHITE, true);
        chev.setGravity(Gravity.CENTER);
        back.addView(chev, new FrameLayout.LayoutParams(MATCH, MATCH));
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { a.back(); }
        });
        left.addView(back, lp(Ui.px(92), Ui.px(92), 0, 0, 0, Ui.px(20), 0));

        TextView t = Ui.text(a, title, 56, Ui.WHITE, true);
        left.addView(t, lp(WRAP, WRAP, 0, 0, 0, Ui.px(14), 0));
        TextView g = Ui.text(a, glyph, 52, Ui.WHITE, false);
        left.addView(g, new LinearLayout.LayoutParams(WRAP, WRAP));

        f.addView(left, new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.LEFT | Gravity.CENTER_VERTICAL));
        f.addView(new LogoView(a, 84), new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.RIGHT | Gravity.CENTER_VERTICAL));
        return f;
    }

    /** Home top bar: settings, network, time | date on the left; logo + tagline on the right. */
    static View topBar(final MainActivity a, boolean withSettings) {
        FrameLayout f = new FrameLayout(a);
        f.setLayoutDirection(View.LAYOUT_DIRECTION_LTR);
        f.setClipChildren(false);

        LinearLayout left = new LinearLayout(a);
        left.setOrientation(LinearLayout.HORIZONTAL);
        left.setGravity(Gravity.CENTER_VERTICAL);
        left.setClipChildren(false);
        if (withSettings) {
            FocusCard gear = new FocusCard(a, Ui.GLASS, Ui.GLASS, 24);
            gear.setTag("gear");
            TextView gl = Ui.text(a, "⚙", 48, Ui.WHITE, false);
            gl.setGravity(Gravity.CENTER);
            gear.addView(gl, new FrameLayout.LayoutParams(MATCH, MATCH));
            gear.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { a.go(MainActivity.Dest.SETTINGS, null); }
            });
            left.addView(gear, lp(Ui.px(84), Ui.px(84), 0, 0, 0, Ui.px(26), 0));
        }
        left.addView(TickText.network(a, 30), lp(WRAP, WRAP, 0, 0, 0, Ui.px(28), 0));
        left.addView(TickText.clock(a, false, 44, Ui.WHITE, true), lp(WRAP, WRAP, 0, 0, 0, Ui.px(28), 0));
        left.addView(TickText.clock(a, true, 30, Ui.TEXT2, false), new LinearLayout.LayoutParams(WRAP, WRAP));
        f.addView(left, new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.LEFT | Gravity.CENTER_VERTICAL));

        LinearLayout right = new LinearLayout(a);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setGravity(Gravity.RIGHT);
        right.addView(new LogoView(a, 76), new LinearLayout.LayoutParams(WRAP, WRAP));
        TextView tag = Ui.text(a, "مشاهدة أذكى .. تجربة أفضل", 28, Ui.TEXT2, false);
        right.addView(tag, new LinearLayout.LayoutParams(WRAP, WRAP));
        f.addView(right, new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.RIGHT | Gravity.CENTER_VERTICAL));
        return f;
    }

    // ------------------------------------------------------------------ cards

    /** A card with a big glyph on top and a title strip at the bottom. */
    static FocusCard iconCard(Context c, String glyph, String title, String sub, int c1, int c2, float glyphSize) {
        FocusCard card = new FocusCard(c, c1, c2, 26);
        TextView g = Ui.text(c, glyph, glyphSize, Ui.WHITE, false);
        g.setGravity(Gravity.CENTER);
        FrameLayout.LayoutParams gp = new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP);
        gp.topMargin = Ui.px(20);
        card.addView(g, gp);
        card.addView(titleStrip(c, title, sub), new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM));
        return card;
    }

    static View titleStrip(Context c, String title, String sub) {
        LinearLayout b = vcol(c);
        b.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{0x00000000, 0xE6050310}));
        b.setPadding(Ui.px(16), Ui.px(26), Ui.px(16), Ui.px(14));
        TextView t = Ui.text(c, title, 34, Ui.WHITE, true);
        t.setMaxLines(2);
        t.setEllipsize(TextUtils.TruncateAt.END);
        b.addView(t, new LinearLayout.LayoutParams(MATCH, WRAP));
        if (sub != null && !sub.isEmpty()) {
            TextView s = Ui.text(c, sub, 28, Ui.TEXT2, false);
            s.setSingleLine(true);
            s.setEllipsize(TextUtils.TruncateAt.END);
            b.addView(s, new LinearLayout.LayoutParams(MATCH, WRAP));
        }
        return b;
    }

    /** Card for an installed app: its real banner/icon plus its real name. Opens the ORIGINAL app. */
    static FocusCard appCard(final MainActivity a, final Apps.AppInfo app) {
        FocusCard card = new FocusCard(a, 0xFF1B1538, 0xFF0F0B24, 24);
        LinearLayout v = vcol(a);
        ImageView iv = new ImageView(a);
        Drawable art = app.banner(a.getPackageManager());
        if (art != null) {
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
        } else {
            art = app.icon(a.getPackageManager());
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setPadding(Ui.px(18), Ui.px(14), Ui.px(18), Ui.px(6));
        }
        if (art != null) iv.setImageDrawable(art);
        v.addView(iv, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        TextView t = Ui.text(a, app.label, 30, Ui.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setSingleLine(true);
        t.setEllipsize(TextUtils.TruncateAt.END);
        t.setPadding(Ui.px(8), Ui.px(8), Ui.px(8), Ui.px(12));
        v.addView(t, new LinearLayout.LayoutParams(MATCH, WRAP));
        card.addView(v, new FrameLayout.LayoutParams(MATCH, MATCH));
        card.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View x) { Launcher.openApp(a, app); }
        });
        return card;
    }

    /**
     * THE priority card. Shows the genuine YouTube logo taken from the installed YouTube app itself,
     * a permanent red frame and the glowing focus frame. OK opens the original app.
     */
    static FocusCard youtubeCard(final MainActivity a, float labelSize, boolean withHint) {
        Apps.AppInfo yt = Apps.youtube(a);
        FocusCard card = new FocusCard(a, 0xFF211635, 0xFF0C0818, 28).accent(0xCCFF2A2A, 3).rimColor(0xFFFF6B6B);
        LinearLayout v = vcol(a);
        v.setGravity(Gravity.CENTER_HORIZONTAL);
        Drawable art = yt == null ? null : yt.banner(a.getPackageManager());
        if (art == null && yt != null) art = yt.icon(a.getPackageManager());
        if (art != null) {
            ImageView iv = new ImageView(a);
            iv.setScaleType(ImageView.ScaleType.FIT_CENTER);
            iv.setPadding(Ui.px(14), Ui.px(14), Ui.px(14), Ui.px(4));
            iv.setImageDrawable(art);
            v.addView(iv, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        } else {
            TextView t = Ui.text(a, "YouTube", labelSize + 10, Ui.WHITE, true);
            t.setGravity(Gravity.CENTER);
            v.addView(t, new LinearLayout.LayoutParams(MATCH, 0, 1f));
        }
        String label = yt != null ? "YouTube" : "YouTube — غير مثبّت";
        TextView l = Ui.text(a, label, labelSize, Ui.WHITE, true);
        l.setGravity(Gravity.CENTER);
        l.setSingleLine(true);
        l.setEllipsize(TextUtils.TruncateAt.END);
        v.addView(l, new LinearLayout.LayoutParams(MATCH, WRAP));
        TextView h = Ui.text(a, withHint ? "اضغط OK للفتح" : "أشهر منصة فيديو", 28, Ui.TEXT2, false);
        h.setGravity(Gravity.CENTER);
        h.setPadding(0, 0, 0, Ui.px(12));
        v.addView(h, new LinearLayout.LayoutParams(MATCH, WRAP));
        card.addView(v, new FrameLayout.LayoutParams(MATCH, MATCH));
        card.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View x) { Launcher.openYouTube(a, null); }
        });
        return card;
    }

    static String glyphForSection(int section) {
        switch (section) {
            case Catalog.MOVIE: return "🎬";
            case Catalog.SERIES: return "📺";
            case Catalog.CHANNEL: return "📡";
            default: return "👑";
        }
    }

    /** Card for a catalog shortcut. OK opens it in YouTube; long OK = favourite / delete menu. */
    static FocusCard itemCard(final MainActivity a, final Catalog.Item it, final Runnable onChanged) {
        int[] col = Ui.cardColors(it.group + it.title);
        FocusCard card = new FocusCard(a, col[0], col[1], 26);
        Bitmap bmp = Ui.poster(a, Ui.px(360), Ui.px(240), it.title, it.id);
        if (bmp != null) {
            ImageView iv = new ImageView(a);
            iv.setImageBitmap(bmp);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            card.addView(iv, new FrameLayout.LayoutParams(MATCH, MATCH));
        } else {
            TextView g = Ui.text(a, glyphForSection(it.section), 72, Ui.WHITE, false);
            g.setGravity(Gravity.CENTER);
            FrameLayout.LayoutParams gp = new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.TOP);
            gp.topMargin = Ui.px(22);
            card.addView(g, gp);
        }
        card.addView(titleStrip(a, it.title, it.group), new FrameLayout.LayoutParams(MATCH, WRAP, Gravity.BOTTOM));
        if (Prefs.isFav(it.id)) {
            TextView heart = Ui.text(a, "♥", 40, 0xFFFF5C8A, true);
            FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(WRAP, WRAP, Gravity.TOP | Gravity.START);
            hp.setMargins(Ui.px(14), Ui.px(12), Ui.px(14), 0);
            card.addView(heart, hp);
        }
        card.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { Launcher.openItem(a, it); }
        });
        card.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                itemMenu(a, it, onChanged);
                return true;
            }
        });
        return card;
    }

    static void itemMenu(final MainActivity a, final Catalog.Item it, final Runnable onChanged) {
        final boolean fav = Prefs.isFav(it.id);
        String[] labels = it.custom
                ? new String[]{fav ? "إزالة من المفضلة" : "إضافة إلى المفضلة", "حذف هذا العنوان", "إغلاق"}
                : new String[]{fav ? "إزالة من المفضلة" : "إضافة إلى المفضلة", "إغلاق"};
        Runnable toggle = new Runnable() {
            @Override public void run() { Prefs.toggleFav(it.id); if (onChanged != null) onChanged.run(); }
        };
        Runnable del = new Runnable() {
            @Override public void run() {
                Catalog.deleteCustom(it.id);
                if (Prefs.isFav(it.id)) Prefs.toggleFav(it.id);
                if (onChanged != null) onChanged.run();
            }
        };
        Runnable[] actions = it.custom ? new Runnable[]{toggle, del, null} : new Runnable[]{toggle, null};
        Dialogs.choose(a, it.title, it.group, labels, actions);
    }

    /** A "+" card (add a shortcut / add a profile). */
    static FocusCard addCard(Context c, String label) {
        FocusCard card = new FocusCard(c, 0x2AFFFFFF, 0x14FFFFFF, 26);
        LinearLayout v = vcol(c);
        v.setGravity(Gravity.CENTER);
        TextView plus = Ui.text(c, "＋", 84, Ui.PURPLE_L, true);
        plus.setGravity(Gravity.CENTER);
        v.addView(plus, new LinearLayout.LayoutParams(WRAP, WRAP));
        TextView t = Ui.text(c, label, 32, Ui.WHITE, true);
        t.setGravity(Gravity.CENTER);
        v.addView(t, new LinearLayout.LayoutParams(WRAP, WRAP));
        card.addView(v, new FrameLayout.LayoutParams(MATCH, MATCH));
        return card;
    }
}
