package com.herotv.app;

import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/** Family profiles (عائلتي / أخي / أبي / ...). Each profile has its own favourites, history and simple-mode choice. */
final class ProfilesScreen extends Screen {
    private static final int MAX_PROFILES = 8;

    ProfilesScreen(MainActivity a) { super(a); }

    @Override
    View build() {
        LinearLayout root = Parts.vcol(act);
        root.setPadding(Ui.px(40), Ui.px(16), Ui.px(40), Ui.px(10));
        root.addView(Parts.header(act, "👥", "الملفات الشخصية"), Parts.lp(Parts.MATCH, Ui.px(100), 0, 0, 0, 0, Ui.px(10)));

        TextView hint = Ui.text(act, "اختر من سيشاهد الآن. لكل ملف مفضلته وسجله الخاص.", 32, Ui.TEXT2, false);
        root.addView(hint, Parts.lp(Parts.MATCH, Parts.WRAP, 0, Ui.px(8), 0, Ui.px(8), Ui.px(10)));

        List<View> cards = new ArrayList<>();
        String active = Prefs.activeProfile();
        for (final Prefs.Profile p : Prefs.profiles()) {
            FocusCard c = new FocusCard(act, p.c1, p.c2, 32);
            LinearLayout v = Parts.vcol(act);
            v.setGravity(Gravity.CENTER);
            TextView g = Ui.text(act, p.glyph, 110, Ui.WHITE, false);
            g.setGravity(Gravity.CENTER);
            v.addView(g, new LinearLayout.LayoutParams(Parts.MATCH, Parts.WRAP));
            TextView n = Ui.text(act, p.name, 44, Ui.WHITE, true);
            n.setGravity(Gravity.CENTER);
            v.addView(n, new LinearLayout.LayoutParams(Parts.MATCH, Parts.WRAP));
            TextView s = Ui.text(act, p.id.equals(active) ? "✓ الحالي" : " ", 30, 0xFF4ADE80, true);
            s.setGravity(Gravity.CENTER);
            v.addView(s, new LinearLayout.LayoutParams(Parts.MATCH, Parts.WRAP));
            c.addView(v, new FrameLayout.LayoutParams(Parts.MATCH, Parts.MATCH));
            if (p.id.equals(active)) c.accent(0xFF4ADE80, 4);
            c.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View x) {
                    Prefs.setActiveProfile(p.id);
                    act.resetHome();               // the new profile's home (simple mode may switch on/off)
                }
            });
            if (!p.builtin) {
                c.setOnLongClickListener(new View.OnLongClickListener() {
                    @Override
                    public boolean onLongClick(View x) {
                        Dialogs.confirm(act, "حذف الملف «" + p.name + "»؟",
                                "تُحذف مفضلة وسجل هذا الملف فقط.", "نعم، احذف",
                                new Runnable() {
                                    @Override public void run() { Prefs.deleteProfile(p.id); act.refresh(); }
                                });
                        return true;
                    }
                });
            }
            cards.add(c);
        }
        if (cards.size() < MAX_PROFILES) {
            FocusCard add = Parts.addCard(act, "إضافة ملف");
            add.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Dialogs.input(act, "ملف جديد", "اسم الشخص", null, new Dialogs.Prompt() {
                        @Override
                        public void done(String first, String second) {
                            Prefs.addProfile(first);
                            act.refresh();
                        }
                    });
                }
            });
            cards.add(add);
        }

        LinearLayout holder = Parts.vcol(act);
        holder.setPadding(Ui.px(10), Ui.px(14), Ui.px(10), Ui.px(40));
        holder.addView(Parts.grid(act, cards, 4, Ui.px(340)), new LinearLayout.LayoutParams(Parts.MATCH, Parts.WRAP));
        root.addView(Parts.scroll(act, holder), new LinearLayout.LayoutParams(Parts.MATCH, 0, 1f));
        firstFocus = cards.get(0);
        return root;
    }
}
