package com.herotv.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;

/** "Hero TV" wordmark + play triangle, drawn in code (no image file). */
final class LogoView extends View {
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint tri = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private final float size;

    /** @param designHeight height in design px (text is ~75% of it). */
    LogoView(Context c, float designHeight) {
        super(c);
        size = Ui.px(designHeight);
        text.setTypeface(Typeface.create(Typeface.DEFAULT_BOLD, Typeface.BOLD_ITALIC));
        text.setTextSize(size * 0.78f);
    }

    @Override
    protected void onMeasure(int wSpec, int hSpec) {
        float w = text.measureText("Hero ") + text.measureText("TV") + size * 0.95f;
        setMeasuredDimension((int) w, (int) size);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        float base = size * 0.74f;
        float x = 0;
        text.setShader(null);
        text.setColor(0xFFFFFFFF);
        canvas.drawText("Hero ", x, base, text);
        x += text.measureText("Hero ");
        float tvW = text.measureText("TV");
        text.setShader(new LinearGradient(x, 0, x + tvW, 0, 0xFFC4B5FD, 0xFF7C3AED, Shader.TileMode.CLAMP));
        canvas.drawText("TV", x, base, text);
        x += tvW + size * 0.12f;

        float t = size * 0.68f;
        float y = size * 0.08f;
        path.reset();
        path.moveTo(x, y);
        path.lineTo(x + t * 0.82f, y + t / 2f);
        path.lineTo(x, y + t);
        path.close();
        tri.setShader(new LinearGradient(x, y, x + t, y + t, 0xFFA78BFA, 0xFF6D28D9, Shader.TileMode.CLAMP));
        canvas.drawPath(path, tri);
    }
}
