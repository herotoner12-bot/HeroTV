package com.herotv.app;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Handler;
import android.os.Looper;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.view.View;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * A TextView that refreshes itself once per minute while it is on screen and stops completely
 * when the screen is hidden / detached (so nothing keeps running in the background).
 */
abstract class TickText extends TextView {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean running;
    private final Runnable tick = new Runnable() {
        @Override
        public void run() {
            if (!running) return;
            refresh();
            long now = System.currentTimeMillis();
            handler.postDelayed(this, 60000 - (now % 60000) + 50); // next minute boundary
        }
    };

    TickText(Context c) {
        super(c);
        setIncludeFontPadding(false);
    }

    abstract void refresh();

    private void start() {
        if (running) return;
        running = true;
        tick.run();
    }

    private void stop() {
        running = false;
        handler.removeCallbacks(tick);
    }

    @Override protected void onAttachedToWindow() { super.onAttachedToWindow(); start(); }

    @Override protected void onDetachedFromWindow() { stop(); super.onDetachedFromWindow(); }

    @Override
    protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        if (visibility == View.VISIBLE) start(); else stop();
    }

    // ------------------------------------------------------------------ clock / date

    /** Western digits with Arabic day / month names, e.g. "20:45" and "السبت 8 نوفمبر". */
    static final Locale AR_LATN = Locale.forLanguageTag("ar-u-nu-latn");

    static TickText clock(Context c, final boolean date, float size, int color, boolean bold) {
        final TickText t = new TickText(c) {
            @Override
            void refresh() {
                String f = date ? "EEEE d MMMM" : (Prefs.clock24() ? "HH:mm" : "h:mm a");
                setText(new SimpleDateFormat(f, AR_LATN).format(new Date()));
            }
        };
        applyStyle(t, size, color, bold);
        return t;
    }

    // ------------------------------------------------------------------ network status

    static TickText network(Context c, float size) {
        final TickText t = new TickText(c) {
            @Override
            void refresh() {
                String label = "غير متصل";
                int color = 0xFFFF6B6B;
                try {
                    ConnectivityManager cm = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
                    Network n = cm == null ? null : cm.getActiveNetwork();
                    NetworkCapabilities nc = n == null ? null : cm.getNetworkCapabilities(n);
                    if (nc != null) {
                        color = 0xFF4ADE80;
                        if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) label = "Wi‑Fi";
                        else if (nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) label = "شبكة سلكية";
                        else label = "متصل";
                    }
                } catch (Throwable ignored) { /* no permission / no service: show offline */ }
                SpannableString s = new SpannableString("● " + label);
                s.setSpan(new ForegroundColorSpan(color), 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                setText(s);
            }
        };
        applyStyle(t, size, Ui.WHITE, false);
        return t;
    }

    private static void applyStyle(TextView t, float size, int color, boolean bold) {
        TextView ref = Ui.text(t.getContext(), "", size, color, bold);
        t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, ref.getTextSize());
        t.setTextColor(color);
        t.setTypeface(ref.getTypeface());
    }
}
