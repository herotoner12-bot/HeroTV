package com.herotv.app;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * All persisted state (survives TV reboot) lives in ONE SharedPreferences file inside the app's
 * private storage. Nothing here touches system settings.
 */
final class Prefs {
    private Prefs() {}

    private static SharedPreferences sp;

    static void init(Context c) {
        sp = c.getApplicationContext().getSharedPreferences("herotv", Context.MODE_PRIVATE);
    }

    // ------------------------------------------------------------------ profiles

    static final class Profile {
        final String id, name, glyph;
        final int c1, c2;
        final boolean builtin;

        Profile(String id, String name, String glyph, int c1, int c2, boolean builtin) {
            this.id = id; this.name = name; this.glyph = glyph;
            this.c1 = c1; this.c2 = c2; this.builtin = builtin;
        }
    }

    private static final int[][] CUSTOM_COLORS = {
            {0xFF9D174D, 0xFF4C1D95}, {0xFF0369A1, 0xFF1E1B4B}, {0xFF15803D, 0xFF134E4A}, {0xFFB45309, 0xFF581C87}
    };

    static List<Profile> profiles() {
        List<Profile> l = new ArrayList<>();
        l.add(new Profile("family", "عائلتي", "👑", 0xFFB45309, 0xFF78350F, true));
        l.add(new Profile("bro", "أخي", "🎮", 0xFF1D4ED8, 0xFF312E81, true));
        l.add(new Profile("dad", "أبي", "👴", 0xFF0F766E, 0xFF134E4A, true));
        JSONArray a = readArray("profiles_custom");
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null) continue;
            int[] col = CUSTOM_COLORS[i % CUSTOM_COLORS.length];
            l.add(new Profile(o.optString("id"), o.optString("name"), "🙂", col[0], col[1], false));
        }
        return l;
    }

    static Profile activeProfileObj() {
        String id = activeProfile();
        for (Profile p : profiles()) if (p.id.equals(id)) return p;
        return profiles().get(0);
    }

    static String activeProfile() { return sp.getString("profile", "family"); }

    static void setActiveProfile(String id) { sp.edit().putString("profile", id).apply(); }

    static void addProfile(String name) {
        JSONArray a = readArray("profiles_custom");
        try {
            a.put(new JSONObject().put("id", "p" + System.currentTimeMillis()).put("name", name));
        } catch (JSONException ignored) { }
        sp.edit().putString("profiles_custom", a.toString()).apply();
    }

    static void deleteProfile(String id) {
        JSONArray a = readArray("profiles_custom");
        JSONArray out = new JSONArray();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o != null && !id.equals(o.optString("id"))) out.put(o);
        }
        SharedPreferences.Editor e = sp.edit().putString("profiles_custom", out.toString());
        e.remove("fav_" + id).remove("recent_" + id).remove("simple_" + id);
        if (id.equals(activeProfile())) e.putString("profile", "family");
        e.apply();
    }

    // ------------------------------------------------------------------ settings

    /** Simple mode is remembered per profile. Default: ON only for the "dad" profile. */
    static boolean simpleMode() {
        String p = activeProfile();
        return sp.getBoolean("simple_" + p, "dad".equals(p));
    }

    static void setSimpleMode(boolean on) { sp.edit().putBoolean("simple_" + activeProfile(), on).apply(); }

    /** 0 = normal, 1 = large, 2 = extra large (ignored in simple mode, which is always large). */
    static int fontLevel() { return sp.getInt("font", 0); }

    static void setFontLevel(int v) { sp.edit().putInt("font", v).apply(); }

    static int wallpaper() { return sp.getInt("wall", 0); }

    static void setWallpaper(int v) { sp.edit().putInt("wall", v).apply(); }

    static boolean clock24() { return sp.getBoolean("clock24", true); }

    static void setClock24(boolean v) { sp.edit().putBoolean("clock24", v).apply(); }

    /** Package name of the TV's own original watching app (chosen by the user in Settings). */
    static String originalApp() { return sp.getString("orig_app", ""); }

    static void setOriginalApp(String pkg) { sp.edit().putString("orig_app", pkg == null ? "" : pkg).apply(); }

    // ------------------------------------------------------------------ favourites / recents (per profile)

    static List<String> favs() { return readIds("fav_" + activeProfile()); }

    static boolean isFav(String id) { return favs().contains(id); }

    static void toggleFav(String id) {
        List<String> l = favs();
        if (!l.remove(id)) l.add(0, id);
        writeIds("fav_" + activeProfile(), l);
    }

    /** Most recent first. */
    static List<String> recents() { return readIds("recent_" + activeProfile()); }

    static void pushRecent(String id) {
        List<String> l = recents();
        l.remove(id);
        l.add(0, id);
        while (l.size() > 24) l.remove(l.size() - 1);
        writeIds("recent_" + activeProfile(), l);
    }

    static void clearRecents() { writeIds("recent_" + activeProfile(), new ArrayList<String>()); }

    // ------------------------------------------------------------------ raw helpers

    static String getString(String k, String def) { return sp.getString(k, def); }

    static void putString(String k, String v) { sp.edit().putString(k, v).apply(); }

    private static JSONArray readArray(String key) {
        try {
            return new JSONArray(sp.getString(key, "[]"));
        } catch (JSONException e) {
            return new JSONArray();
        }
    }

    private static List<String> readIds(String key) {
        List<String> l = new ArrayList<>();
        JSONArray a = readArray(key);
        for (int i = 0; i < a.length(); i++) l.add(a.optString(i));
        return l;
    }

    private static void writeIds(String key, List<String> l) {
        JSONArray a = new JSONArray();
        for (String s : l) a.put(s);
        sp.edit().putString(key, a.toString()).apply();
    }
}
