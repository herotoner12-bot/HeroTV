package com.herotv.app;

import android.app.Dialog;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Big, remote-friendly dialogs (default system dialogs use small text). Back closes a dialog. */
final class Dialogs {
    private Dialogs() {}

    interface Prompt { void done(String first, String second); }

    private static final int MATCH = ViewGroup.LayoutParams.MATCH_PARENT;
    private static final int WRAP = ViewGroup.LayoutParams.WRAP_CONTENT;

    private static Dialog base(MainActivity a, LinearLayout panel) {
        final Dialog d = new Dialog(a);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        FrameLayout root = new FrameLayout(a);
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        root.setBackgroundColor(0xCC05030F);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Ui.px(1100), WRAP, Gravity.CENTER);
        root.addView(panel, lp);
        d.setContentView(root);
        Window w = d.getWindow();
        if (w != null) {
            w.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            w.setLayout(MATCH, MATCH);
            w.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN
                    | WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        }
        d.setCancelable(true);
        return d;
    }

    private static LinearLayout panel(MainActivity a, String title, String body) {
        LinearLayout p = new LinearLayout(a);
        p.setOrientation(LinearLayout.VERTICAL);
        p.setBackground(Ui.box(0xFF171033, 34, 0x66B794FF, 3));
        p.setPadding(Ui.px(56), Ui.px(48), Ui.px(56), Ui.px(40));
        p.setClipChildren(false);
        TextView t = Ui.text(a, title, 46, Ui.WHITE, true);
        p.addView(t, new LinearLayout.LayoutParams(MATCH, WRAP));
        if (body != null && !body.isEmpty()) {
            TextView b = Ui.text(a, body, 34, Ui.TEXT2, false);
            b.setLineSpacing(0, 1.25f);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, WRAP);
            lp.topMargin = Ui.px(22);
            p.addView(b, lp);
        }
        return p;
    }

    private static FocusCard button(MainActivity a, String label, boolean primary) {
        FocusCard c = primary ? new FocusCard(a, Ui.PURPLE, Ui.BLUE_D, 22)
                : new FocusCard(a, 0x33FFFFFF, 0x22FFFFFF, 22);
        TextView t = Ui.text(a, label, 36, Ui.WHITE, true);
        t.setGravity(Gravity.CENTER);
        c.addView(t, new FrameLayout.LayoutParams(MATCH, MATCH));
        return c;
    }

    private static void addButton(LinearLayout panel, FocusCard b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, Ui.px(88));
        lp.topMargin = Ui.px(18);
        panel.addView(b, lp);
    }

    /** One OK button. */
    static void info(MainActivity a, String title, String body) {
        choose(a, title, body, new String[]{"حسناً"}, new Runnable[]{null});
    }

    /** Several buttons; actions[i] may be null (just closes). First button gets the focus. */
    static void choose(MainActivity a, String title, String body, String[] labels, final Runnable[] actions) {
        LinearLayout p = panel(a, title, body);
        final Dialog d = base(a, p);
        FocusCard first = null;
        for (int i = 0; i < labels.length; i++) {
            final int k = i;
            FocusCard b = button(a, labels[i], i == 0);
            b.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    d.dismiss();
                    if (actions != null && k < actions.length && actions[k] != null) actions[k].run();
                }
            });
            addButton(p, b);
            if (first == null) first = b;
        }
        final FocusCard f = first;
        d.setOnShowListener(new android.content.DialogInterface.OnShowListener() {
            @Override public void onShow(android.content.DialogInterface di) { if (f != null) f.requestFocus(); }
        });
        d.show();
    }

    static void confirm(MainActivity a, String title, String body, String yes, Runnable onYes) {
        choose(a, title, body, new String[]{yes, "إلغاء"}, new Runnable[]{onYes, null});
    }

    /** One or two text fields (typed with the TV keyboard). second may be null. */
    static void input(MainActivity a, String title, String hint1, String hint2, final Prompt cb) {
        LinearLayout p = panel(a, title, null);
        final Dialog d = base(a, p);
        final EditText e1 = field(a, hint1, hint2 == null);
        final EditText e2 = hint2 == null ? null : field(a, hint2, true);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(MATCH, Ui.px(96));
        lp.topMargin = Ui.px(24);
        p.addView(e1, lp);
        if (e2 != null) {
            LinearLayout.LayoutParams lp2 = new LinearLayout.LayoutParams(MATCH, Ui.px(96));
            lp2.topMargin = Ui.px(16);
            p.addView(e2, lp2);
        }
        FocusCard ok = button(a, "حفظ", true);
        ok.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s1 = e1.getText().toString().trim();
                String s2 = e2 == null ? "" : e2.getText().toString().trim();
                if (s1.isEmpty()) return;      // title is required
                d.dismiss();
                cb.done(s1, s2);
            }
        });
        addButton(p, ok);
        FocusCard cancel = button(a, "إلغاء", false);
        cancel.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { d.dismiss(); }
        });
        addButton(p, cancel);
        d.setOnShowListener(new android.content.DialogInterface.OnShowListener() {
            @Override public void onShow(android.content.DialogInterface di) { e1.requestFocus(); }
        });
        d.show();
    }

    private static EditText field(MainActivity a, String hint, boolean last) {
        EditText e = new EditText(a);
        e.setHint(hint);
        e.setHintTextColor(Ui.MUTED);
        e.setTextColor(Ui.WHITE);
        e.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, Ui.px(36));
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT);
        e.setImeOptions(last ? EditorInfo.IME_ACTION_DONE : EditorInfo.IME_ACTION_NEXT);
        e.setGravity(Gravity.CENTER_VERTICAL | Gravity.START);
        e.setPadding(Ui.px(28), 0, Ui.px(28), 0);
        e.setBackground(Ui.box(0x33FFFFFF, 20, 0x66B794FF, 2));
        return e;
    }

    /** Shown when the original YouTube app is not installed — we never pretend it works. */
    static void youtubeMissing(final MainActivity a) {
        choose(a, "YouTube غير مثبّت",
                "تطبيق YouTube الأصلي غير مثبّت على هذا التلفزيون.\n"
                        + "ثبّته من متجر التطبيقات (Google Play) ثم عُد إلى Hero TV.\n"
                        + "Hero TV لا يفتح موقع YouTube في المتصفح ولا يصنع نسخة بديلة.",
                new String[]{"فتح صفحة YouTube في المتجر", "إغلاق"},
                new Runnable[]{new Runnable() {
                    @Override public void run() { Launcher.openStorePage(a, Apps.YOUTUBE[0]); }
                }, null});
    }
}
