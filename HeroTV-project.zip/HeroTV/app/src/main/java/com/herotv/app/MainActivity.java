package com.herotv.app;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;

import java.util.ArrayList;

/**
 * The single activity. Pages are plain views swapped inside one FrameLayout (cheap on RAM).
 * Navigation is a simple stack: OK goes forward, BACK returns to the previous page, and BACK on
 * the first page leaves Hero TV (-> the TV's original home screen, which is never touched).
 */
public class MainActivity extends Activity {

    enum Dest { HOME, MOVIES, SERIES, CHANNELS, APPS, FAVORITES, CONTINUE, BROTHER, PROFILES, SETTINGS, REST, PICK_ORIGINAL }

    private static final class Entry {
        final Dest dest;
        final String arg;

        Entry(Dest d, String a) { dest = d; arg = a; }

        boolean same(Dest d, String a) {
            return dest == d && (arg == null ? a == null : arg.equals(a));
        }
    }

    private final ArrayList<Entry> stack = new ArrayList<>();
    private FrameLayout stage;
    private BackgroundView bg;
    private boolean refreshOnResume;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Prefs.init(this);
        Ui.init(this);

        stage = new FrameLayout(this);
        stage.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);   // full RTL regardless of the TV language
        stage.setClipChildren(false);
        bg = new BackgroundView(this, Prefs.wallpaper(), true);
        setContentView(stage);

        stack.add(new Entry(Dest.HOME, null));
        render();   // NOTE: nothing is launched or played automatically on start.
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (refreshOnResume) {            // came back from another app: refresh recents / installed apps
            refreshOnResume = false;
            render();
        }
    }

    /** Called right before another app is started from Hero TV. */
    void markLaunch() { refreshOnResume = true; }

    // ------------------------------------------------------------------ navigation

    void go(Dest d, String arg) {
        for (int i = 0; i < stack.size(); i++) {
            if (stack.get(i).same(d, arg)) {           // already in the history: go back to it
                while (stack.size() > i + 1) stack.remove(stack.size() - 1);
                render();
                return;
            }
        }
        stack.add(new Entry(d, arg));
        render();
    }

    void back() {
        if (stack.size() > 1) {
            stack.remove(stack.size() - 1);
            render();
        } else {
            finish();          // leaves Hero TV; the original TV interface is right behind it
        }
    }

    void resetHome() {
        stack.clear();
        stack.add(new Entry(Dest.HOME, null));
        render();
    }

    /** Re-draw the current page (after a setting changed). */
    void refresh() { render(); }

    Dest current() { return stack.get(stack.size() - 1).dest; }

    @Override
    public void onBackPressed() { back(); }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (current() == Dest.REST
                && keyCode != KeyEvent.KEYCODE_VOLUME_UP
                && keyCode != KeyEvent.KEYCODE_VOLUME_DOWN
                && keyCode != KeyEvent.KEYCODE_VOLUME_MUTE) {
            if (event.getRepeatCount() == 0) back();   // any remote key leaves rest mode
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }

    // ------------------------------------------------------------------ rendering

    private Screen create(Entry e) {
        switch (e.dest) {
            case MOVIES:
                return new ContentScreen(this, ContentScreen.SECTION, Catalog.MOVIE, "الأفلام", "🎬", e.arg);
            case SERIES:
                return new ContentScreen(this, ContentScreen.SECTION, Catalog.SERIES, "المسلسلات", "📺", e.arg);
            case CHANNELS:
                return new ContentScreen(this, ContentScreen.SECTION, Catalog.CHANNEL, "القنوات", "📡", e.arg);
            case BROTHER:
                return new ContentScreen(this, ContentScreen.SECTION, Catalog.BROTHER, "عالم أخي", "👑", e.arg);
            case FAVORITES:
                return new ContentScreen(this, ContentScreen.FAVORITES, -1, "المفضلة", "⭐", null);
            case CONTINUE:
                return new ContentScreen(this, ContentScreen.RECENT, -1, "أكمل المشاهدة", "🕒", null);
            case APPS:
                return new AppsScreen(this, false);
            case PICK_ORIGINAL:
                return new AppsScreen(this, true);
            case PROFILES:
                return new ProfilesScreen(this);
            case SETTINGS:
                return new SettingsScreen(this);
            case REST:
                return new RestScreen(this);
            case HOME:
            default:
                return Prefs.simpleMode() ? new SimpleHomeScreen(this) : new HomeScreen(this);
        }
    }

    private void render() {
        Ui.refresh();
        bg.setWallpaper(Prefs.wallpaper());
        stage.removeAllViews();
        if (bg.getParent() != null) ((ViewGroup) bg.getParent()).removeView(bg);
        stage.addView(bg, new FrameLayout.LayoutParams(Parts.MATCH, Parts.MATCH));

        final Screen s = create(stack.get(stack.size() - 1));
        View v = s.build();
        stage.addView(v, new FrameLayout.LayoutParams(Parts.MATCH, Parts.MATCH));
        stage.post(new Runnable() {
            @Override
            public void run() {
                if (s.firstFocus != null) s.firstFocus.requestFocus();
            }
        });
    }
}
