package com.herotv.app;

import android.content.Context;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;

/**
 * "الوضع البسيط" — made for the father. One giant YouTube card first, then only four big choices.
 * No side menu, no nested menus, big Arabic text. D-pad + OK + Back only.
 */
final class SimpleHomeScreen extends Screen {

    SimpleHomeScreen(MainActivity a) { super(a); }

    @Override
    View build() {
        Context c = act;
        LinearLayout col = Parts.vcol(c);
        col.setPadding(Ui.px(64), Ui.px(20), Ui.px(64), Ui.px(36));

        col.addView(Parts.topBar(act, false), Parts.lp(Parts.MATCH, Ui.px(110), 0, 0, 0, 0, Ui.px(14)));

        // 1) YouTube: the biggest, first, already focused => one press of OK.
        FocusCard yt = Parts.youtubeCard(act, 40, true);
        col.addView(yt, Parts.lp(Parts.MATCH, Ui.px(390), 0, 0, Ui.px(8), 0, Ui.px(20)));
        firstFocus = yt;

        // 2) four big choices
        LinearLayout row = Parts.hrow(c, 4);
        int g = Ui.px(10);

        Apps.AppInfo orig = Apps.find(act, Prefs.originalApp());
        if (orig != null) {
            FocusCard tv = Parts.iconCard(c, "📺", orig.label, "التلفاز الأصلي", 0xFF0F766E, 0xFF1E1B4B, 66);
            final Apps.AppInfo o = orig;
            tv.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { Launcher.openApp(act, o); }
            });
            row.addView(tv, Parts.lp(0, Parts.MATCH, 1f, g, g, g, g));
        } else {
            FocusCard tv = Parts.iconCard(c, "📺", "تلفزيوننا", "اضغط لاختيار التطبيق", 0xFF0F766E, 0xFF1E1B4B, 66);
            tv.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { act.go(MainActivity.Dest.PICK_ORIGINAL, null); }
            });
            row.addView(tv, Parts.lp(0, Parts.MATCH, 1f, g, g, g, g));
        }
        row.addView(big("🕒", "أكمل المشاهدة", 0xFF9D174D, 0xFF3B0764, MainActivity.Dest.CONTINUE),
                Parts.lp(0, Parts.MATCH, 1f, g, g, g, g));
        row.addView(big("⊞", "كل التطبيقات", 0xFF1D4ED8, 0xFF1E1B4B, MainActivity.Dest.APPS),
                Parts.lp(0, Parts.MATCH, 1f, g, g, g, g));
        row.addView(big("⚙", "الإعدادات", 0xFF4338CA, 0xFF0F172A, MainActivity.Dest.SETTINGS),
                Parts.lp(0, Parts.MATCH, 1f, g, g, g, g));
        col.addView(row, Parts.lp(Parts.MATCH, Ui.px(250), 0, 0, 0, 0, 0));

        ScrollView sv = Parts.scroll(c, col);
        return sv;
    }

    private FocusCard big(String glyph, String title, int c1, int c2, final MainActivity.Dest d) {
        FocusCard card = Parts.iconCard(act, glyph, title, null, c1, c2, 66);
        card.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { act.go(d, null); }
        });
        return card;
    }
}
