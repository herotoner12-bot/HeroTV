package com.herotv.app;

import android.view.View;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import java.util.ArrayList;
import java.util.List;

/**
 * Every app that is really installed on the TV. OK opens the original app.
 * In "pick" mode (from Settings / Home) OK chooses the TV's own original watching app instead.
 */
final class AppsScreen extends Screen {
    private final boolean pick;

    AppsScreen(MainActivity a, boolean pick) {
        super(a);
        this.pick = pick;
    }

    @Override
    View build() {
        LinearLayout root = Parts.vcol(act);
        root.setPadding(Ui.px(40), Ui.px(16), Ui.px(40), Ui.px(10));

        View header = Parts.header(act, "⊞", pick ? "اختر تطبيق المشاهدة الأصلي" : "التطبيقات");
        View back = header.findViewWithTag("back");
        root.addView(header, Parts.lp(Parts.MATCH, Ui.px(100), 0, 0, 0, 0, Ui.px(10)));

        List<View> cards = new ArrayList<>();
        Apps.AppInfo yt = Apps.youtube(act);

        if (pick) {
            FocusCard none = Parts.addCard(act, "بدون تحديد");
            none.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Prefs.setOriginalApp("");
                    act.back();
                }
            });
            cards.add(none);
        } else if (yt == null) {
            // YouTube is always the first card — if missing we say so instead of pretending.
            cards.add(Parts.youtubeCard(act, 30, false));
        }

        for (final Apps.AppInfo app : Apps.all(act)) {
            if (!pick && yt != null && app.pkg.equals(yt.pkg)) {
                cards.add(0, Parts.youtubeCard(act, 30, false));   // genuine YouTube first
                continue;
            }
            if (pick) {
                FocusCard c = Parts.appCard(act, app);
                c.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Prefs.setOriginalApp(app.pkg);
                        act.back();
                    }
                });
                cards.add(c);
            } else {
                cards.add(Parts.appCard(act, app));
            }
        }

        LinearLayout holder = Parts.vcol(act);
        holder.setPadding(Ui.px(10), Ui.px(14), Ui.px(10), Ui.px(40));
        int cols = Ui.simple() ? 3 : 5;
        holder.addView(Parts.grid(act, cards, cols, Ui.px(Ui.simple() ? 270 : 210)),
                new LinearLayout.LayoutParams(Parts.MATCH, Parts.WRAP));
        ScrollView sv = Parts.scroll(act, holder);
        root.addView(sv, new LinearLayout.LayoutParams(Parts.MATCH, 0, 1f));

        firstFocus = cards.isEmpty() ? back : cards.get(0);
        return root;
    }
}
