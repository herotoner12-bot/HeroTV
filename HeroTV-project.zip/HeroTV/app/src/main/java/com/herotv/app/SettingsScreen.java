package com.herotv.app;

import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Hero TV settings. Everything here only changes Hero TV's own saved preferences.
 * The two buttons that leave the app (original home / system settings) act only when pressed.
 */
final class SettingsScreen extends Screen {

    SettingsScreen(MainActivity a) { super(a); }

    @Override
    View build() {
        LinearLayout root = Parts.vcol(act);
        root.setPadding(Ui.px(40), Ui.px(16), Ui.px(40), Ui.px(10));
        View header = Parts.header(act, "⚙", "الإعدادات");
        root.addView(header, Parts.lp(Parts.MATCH, Ui.px(100), 0, 0, 0, 0, Ui.px(10)));

        LinearLayout list = Parts.vcol(act);
        list.setPadding(Ui.px(10), Ui.px(10), Ui.px(10), Ui.px(40));

        // 1) simple mode
        FocusCard simple = row("الوضع البسيط", Prefs.simpleMode() ? "مفعّل ✓" : "متوقف", new Runnable() {
            @Override
            public void run() {
                Prefs.setSimpleMode(!Prefs.simpleMode());
                act.resetHome();
                act.go(MainActivity.Dest.SETTINGS, null);
            }
        });
        list.addView(simple, rowLp());
        firstFocus = simple;

        // 2) font size
        String[] fonts = {"عادي", "كبير", "كبير جداً"};
        list.addView(row("حجم الخط", fonts[Prefs.fontLevel()], new Runnable() {
            @Override
            public void run() {
                Prefs.setFontLevel((Prefs.fontLevel() + 1) % 3);
                act.refresh();
            }
        }), rowLp());

        // 3) clock format
        list.addView(row("تنسيق الوقت", Prefs.clock24() ? "24 ساعة" : "12 ساعة", new Runnable() {
            @Override
            public void run() {
                Prefs.setClock24(!Prefs.clock24());
                act.refresh();
            }
        }), rowLp());

        // 4) wallpaper
        list.addView(Ui.text(act, "الخلفية", 36, Ui.WHITE, true), Parts.lp(Parts.MATCH, Parts.WRAP, 0, Ui.px(14), Ui.px(18), Ui.px(14), Ui.px(8)));
        LinearLayout walls = Parts.hrow(act, BackgroundView.NAMES.length);
        for (int i = 0; i < BackgroundView.NAMES.length; i++) {
            final int idx = i;
            int[] col = BackgroundView.swatch(i);
            FocusCard sw = new FocusCard(act, col[1], col[2], 24);
            TextView t = Ui.text(act, (Prefs.wallpaper() == i ? "✓ " : "") + BackgroundView.NAMES[i], 28, Ui.WHITE, true);
            t.setGravity(Gravity.CENTER);
            sw.addView(t, new FrameLayout.LayoutParams(Parts.MATCH, Parts.MATCH));
            if (Prefs.wallpaper() == i) sw.accent(0xFFFFFFFF, 4);
            sw.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Prefs.setWallpaper(idx);
                    act.refresh();
                }
            });
            walls.addView(sw, Parts.lp(0, Ui.px(120), 1f, Ui.px(8), Ui.px(6), Ui.px(8), Ui.px(6)));
        }
        list.addView(walls, new LinearLayout.LayoutParams(Parts.MATCH, Parts.WRAP));

        // 5) original watching app
        Apps.AppInfo orig = Apps.find(act, Prefs.originalApp());
        list.addView(row("تطبيق المشاهدة الأصلي للتلفزيون", orig == null ? "غير محدد" : orig.label, new Runnable() {
            @Override public void run() { act.go(MainActivity.Dest.PICK_ORIGINAL, null); }
        }), Parts.lp(Parts.MATCH, Ui.px(96), 0, Ui.px(8), Ui.px(18), Ui.px(8), Ui.px(8)));

        // 6) back to the original interface
        FocusCard orig2 = row("العودة إلى واجهة التلفزيون الأصلية", "الآن", new Runnable() {
            @Override public void run() { Launcher.goToOriginalHome(act); }
        });
        orig2.fill(0xFF14532D, 0xFF052E16);
        list.addView(orig2, rowLp());

        // 7) system settings (user-initiated only)
        list.addView(row("إعدادات التلفزيون (Wi‑Fi، الصوت، ...)", "فتح", new Runnable() {
            @Override public void run() { Launcher.openSystemSettings(act); }
        }), rowLp());

        // 8) about / how to revert
        list.addView(row("عن Hero TV وطريقة الرجوع", "عرض", new Runnable() {
            @Override
            public void run() {
                Dialogs.info(act, "Hero TV — الإصدار 1.0.0",
                        "Hero TV تطبيق عادي، لا يستبدل واجهة التلفزيون ولا يحذف أو يعطّل أي تطبيق.\n\n"
                                + "للرجوع إلى الواجهة الأصلية في أي وقت: اضغط زر Home في الريموت، أو زر الرجوع من الصفحة الرئيسية.\n\n"
                                + "لإزالة Hero TV نهائياً: إعدادات التلفزيون ← التطبيقات ← Hero TV ← إلغاء التثبيت.");
            }
        }), rowLp());

        root.addView(Parts.scroll(act, list), new LinearLayout.LayoutParams(Parts.MATCH, 0, 1f));
        return root;
    }

    private LinearLayout.LayoutParams rowLp() {
        return Parts.lp(Parts.MATCH, Ui.px(96), 0, Ui.px(8), Ui.px(7), Ui.px(8), Ui.px(7));
    }

    /** A wide setting row: label on the right, current value on the left. */
    private FocusCard row(String label, String value, final Runnable action) {
        FocusCard c = new FocusCard(act, 0x33FFFFFF, 0x1AFFFFFF, 26);
        LinearLayout r = Parts.hrow(act, 0);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(Ui.px(32), 0, Ui.px(32), 0);
        TextView l = Ui.text(act, label, 36, Ui.WHITE, true);
        r.addView(l, new LinearLayout.LayoutParams(0, Parts.WRAP, 1f));
        TextView v = Ui.text(act, value, 34, Ui.PURPLE_L, true);
        v.setGravity(Gravity.CENTER_VERTICAL | Gravity.END);
        r.addView(v, new LinearLayout.LayoutParams(Parts.WRAP, Parts.WRAP));
        c.addView(r, new FrameLayout.LayoutParams(Parts.MATCH, Parts.MATCH));
        c.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View x) { action.run(); }
        });
        return c;
    }
}
