package com.herotv.app;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/** Read-only view of the apps that are REALLY installed on this TV. Never installs/removes anything. */
final class Apps {
    private Apps() {}

    /** The genuine YouTube apps, in order of preference (Android TV first). No third-party clients. */
    static final String[] YOUTUBE = {"com.google.android.youtube.tv", "com.google.android.youtube"};

    /** Shown on the home row (only if installed), after YouTube and the TV's original app. */
    private static final String[] POPULAR = {
            "com.netflix.ninja", "com.netflix.mediaclient",
            "com.amazon.amazonvideo.livingroom", "com.amazon.avod.thirdpartyclient",
            "com.disney.disneyplus", "net.mbc.shahid", "com.spotify.tv.android",
            "com.google.android.youtube.tvkids", "com.twitch.android.app"
    };

    static final class AppInfo {
        final String pkg, label;
        final ResolveInfo ri;

        AppInfo(String pkg, String label, ResolveInfo ri) {
            this.pkg = pkg; this.label = label; this.ri = ri;
        }

        /** The app's own TV banner (its real logo artwork), or null. */
        Drawable banner(PackageManager pm) {
            try {
                return ri.activityInfo.loadBanner(pm);
            } catch (Throwable t) {
                return null;
            }
        }

        Drawable icon(PackageManager pm) {
            try {
                return ri.loadIcon(pm);
            } catch (Throwable t) {
                return null;
            }
        }
    }

    /** All launchable apps except Hero TV itself, sorted by name. */
    static List<AppInfo> all(Context c) {
        PackageManager pm = c.getPackageManager();
        Map<String, AppInfo> map = new LinkedHashMap<>();
        collect(pm, map, Intent.CATEGORY_LEANBACK_LAUNCHER, c.getPackageName());
        collect(pm, map, Intent.CATEGORY_LAUNCHER, c.getPackageName());
        List<AppInfo> l = new ArrayList<>(map.values());
        Collections.sort(l, new Comparator<AppInfo>() {
            @Override
            public int compare(AppInfo a, AppInfo b) { return a.label.compareToIgnoreCase(b.label); }
        });
        return l;
    }

    private static void collect(PackageManager pm, Map<String, AppInfo> map, String category, String self) {
        Intent q = new Intent(Intent.ACTION_MAIN).addCategory(category);
        List<ResolveInfo> list;
        try {
            list = pm.queryIntentActivities(q, 0);
        } catch (Throwable t) {
            return;
        }
        for (ResolveInfo ri : list) {
            if (ri.activityInfo == null) continue;
            String pkg = ri.activityInfo.packageName;
            if (pkg.equals(self) || map.containsKey(pkg)) continue;
            CharSequence label = ri.loadLabel(pm);
            map.put(pkg, new AppInfo(pkg, label == null ? pkg : label.toString(), ri));
        }
    }

    static AppInfo find(Context c, String pkg) {
        if (pkg == null || pkg.isEmpty()) return null;
        for (AppInfo a : all(c)) if (a.pkg.equals(pkg)) return a;
        return null;
    }

    /** The genuine installed YouTube app, or null when it is not installed. */
    static AppInfo youtube(Context c) {
        List<AppInfo> all = all(c);
        for (String p : YOUTUBE) {
            for (AppInfo a : all) if (a.pkg.equals(p)) return a;
        }
        return null;
    }

    /** Apps for the home row after YouTube + original app: popular ones that are really installed. */
    static List<AppInfo> popularInstalled(Context c, int max, String excludePkg) {
        List<AppInfo> all = all(c);
        List<AppInfo> out = new ArrayList<>();
        for (String p : POPULAR) {
            if (out.size() >= max) break;
            if (p.equals(excludePkg)) continue;
            for (AppInfo a : all) {
                if (a.pkg.equals(p)) {
                    out.add(a);
                    break;
                }
            }
        }
        return out;
    }
}
