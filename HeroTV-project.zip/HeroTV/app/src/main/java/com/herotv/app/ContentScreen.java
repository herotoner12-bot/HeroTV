package com.herotv.app;

import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * One class for Movies, Series, Channels, "عالم أخي", Favourites and Continue-watching.
 * Category chips on top (movies / series / channels / brother), cards below.
 * OK = open in the ORIGINAL YouTube app, long OK = favourite / delete menu.
 */
final class ContentScreen extends Screen {
    static final int SECTION = 0, FAVORITES = 1, RECENT = 2;

    private static final String ALL = "الكل", FAV = "المفضلة", REC = "متابعة المشاهدة";

    private final int mode, section;
    private final String title, glyph;
    private String group;
    private final List<String> chips = new ArrayList<>();
    private final List<FocusCard> chipViews = new ArrayList<>();
    private LinearLayout gridHolder;
    private View backBtn;

    ContentScreen(MainActivity a, int mode, int section, String title, String glyph, String initialGroup) {
        super(a);
        this.mode = mode;
        this.section = section;
        this.title = title;
        this.glyph = glyph;
        if (mode == SECTION) {
            if (section != Catalog.BROTHER) chips.add(ALL);
            chips.addAll(Catalog.groups(section));
            if (section == Catalog.BROTHER) {          // the 7 categories from the brief
                chips.add(FAV);
                chips.add(REC);
            }
            if (initialGroup != null && chips.contains(initialGroup)) group = initialGroup;
            else group = chips.get(0);
        } else {
            group = "";
        }
    }

    @Override
    View build() {
        LinearLayout root = Parts.vcol(act);
        root.setPadding(Ui.px(40), Ui.px(16), Ui.px(40), Ui.px(10));

        View header = Parts.header(act, glyph, title);
        backBtn = header.findViewWithTag("back");
        root.addView(header, Parts.lp(Parts.MATCH, Ui.px(100), 0, 0, 0, 0, Ui.px(10)));

        if (mode == SECTION) root.addView(chipsRow(), Parts.lp(Parts.MATCH, Parts.WRAP, 0, 0, 0, 0, Ui.px(6)));

        gridHolder = Parts.vcol(act);
        gridHolder.setPadding(Ui.px(10), Ui.px(14), Ui.px(10), Ui.px(40));
        ScrollView sv = Parts.scroll(act, gridHolder);
        root.addView(sv, new LinearLayout.LayoutParams(Parts.MATCH, 0, 1f));

        fillGrid(true);
        return root;
    }

    // ------------------------------------------------------------------ chips

    private View chipsRow() {
        LinearLayout r = Parts.hrow(act, 0);
        r.setPadding(Ui.px(6), Ui.px(6), Ui.px(6), Ui.px(10));
        chipViews.clear();
        for (final String g : chips) {
            final FocusCard chip = new FocusCard(act, Ui.GLASS, Ui.GLASS, 36);
            TextView t = Ui.text(act, g, 30, Ui.WHITE, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(Ui.px(30), 0, Ui.px(30), 0);
            chip.addView(t, new FrameLayout.LayoutParams(Parts.WRAP, Parts.MATCH));
            chip.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    group = g;
                    styleChips();
                    fillGrid(false);
                }
            });
            chipViews.add(chip);
            r.addView(chip, Parts.lp(Parts.WRAP, Ui.px(76), 0, Ui.px(8), Ui.px(4), Ui.px(8), Ui.px(4)));
        }
        styleChips();
        return r;
    }

    private void styleChips() {
        for (int i = 0; i < chipViews.size(); i++) {
            boolean sel = chips.get(i).equals(group);
            if (sel) chipViews.get(i).fill(Ui.PURPLE, Ui.BLUE);
            else chipViews.get(i).fill(Ui.GLASS, Ui.GLASS);
        }
    }

    // ------------------------------------------------------------------ cards

    private List<Catalog.Item> currentItems() {
        List<Catalog.Item> out = new ArrayList<>();
        if (mode == FAVORITES) {
            for (String id : Prefs.favs()) {
                Catalog.Item it = Catalog.byId(id);
                if (it != null) out.add(it);
            }
        } else if (mode == RECENT) {
            for (String id : Prefs.recents()) {
                Catalog.Item it = Catalog.byId(id);
                if (it != null) out.add(it);
            }
        } else if (FAV.equals(group)) {
            for (String id : Prefs.favs()) {
                Catalog.Item it = Catalog.byId(id);
                if (it != null && it.section == section) out.add(it);
            }
        } else if (REC.equals(group)) {
            for (String id : Prefs.recents()) {
                Catalog.Item it = Catalog.byId(id);
                if (it != null && it.section == section) out.add(it);
            }
        } else {
            for (Catalog.Item it : Catalog.inSection(section)) {
                if (ALL.equals(group) || it.group.equals(group)) out.add(it);
            }
        }
        return out;
    }

    private boolean canAdd() {
        return mode == SECTION && !Ui.simple() && !FAV.equals(group) && !REC.equals(group);
    }

    private void fillGrid(boolean initial) {
        gridHolder.removeAllViews();
        List<Catalog.Item> items = currentItems();
        List<View> cards = new ArrayList<>();
        Runnable changed = new Runnable() {
            @Override public void run() { fillGrid(false); }
        };
        for (Catalog.Item it : items) cards.add(Parts.itemCard(act, it, changed));

        if (canAdd()) cards.add(addShortcutCard());
        if (mode == RECENT && !items.isEmpty()) {
            FocusCard clear = Parts.addCard(act, "مسح القائمة");
            clear.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Dialogs.confirm(act, "مسح «أكمل المشاهدة»؟", "سيُمسح السجل فقط. لن يُحذف أي تطبيق أو فيديو.", "نعم، امسح",
                            new Runnable() {
                                @Override public void run() { Prefs.clearRecents(); fillGrid(false); }
                            });
                }
            });
            cards.add(clear);
        }

        if (cards.isEmpty()) {
            String msg = mode == FAVORITES
                    ? "لا يوجد شيء في المفضلة بعد.\nاضغط مطولاً على OK فوق أي عنوان لإضافته."
                    : mode == RECENT
                    ? "لم تفتح شيئاً عبر Hero TV بعد.\nكل ما تفتحه سيظهر هنا."
                    : "لا يوجد شيء هنا بعد.";
            FrameLayout f = new FrameLayout(act);
            f.addView(Parts.centerMessage(act, msg), new FrameLayout.LayoutParams(Parts.MATCH, Ui.px(400), Gravity.CENTER));
            gridHolder.addView(f, new LinearLayout.LayoutParams(Parts.MATCH, Parts.WRAP));
        } else {
            int cols = Ui.simple() ? 3 : 5;
            int h = Ui.px(Ui.simple() ? 310 : 240);
            gridHolder.addView(Parts.grid(act, cards, cols, h), new LinearLayout.LayoutParams(Parts.MATCH, Parts.WRAP));
        }

        // focus: first card on first open; after a change keep the user inside the page
        View target = null;
        if (!items.isEmpty() || canAdd()) target = firstFocusable(gridHolder);
        if (target == null) target = backBtn;
        final View t = target;
        if (initial) firstFocus = t;
        else if (t != null) t.post(new Runnable() {
            @Override public void run() { t.requestFocus(); }
        });
    }

    private static View firstFocusable(View v) {
        if (v.isFocusable()) return v;
        if (v instanceof android.view.ViewGroup) {
            android.view.ViewGroup g = (android.view.ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                View r = firstFocusable(g.getChildAt(i));
                if (r != null) return r;
            }
        }
        return null;
    }

    private View addShortcutCard() {
        FocusCard add = Parts.addCard(act, "إضافة عنوان");
        add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final List<String> groups = Catalog.groups(section);
                final String target = groups.contains(group) ? group : (groups.isEmpty() ? "عام" : groups.get(0));
                Dialogs.input(act, "إضافة إلى: " + target, "اسم العنوان (مثال: باب الحارة الجزء 3)",
                        "كلمات البحث في YouTube (اختياري)", new Dialogs.Prompt() {
                            @Override
                            public void done(String first, String second) {
                                Catalog.addCustom(section, target, first, second.isEmpty() ? first : second);
                                fillGrid(false);
                            }
                        });
            }
        });
        return add;
    }
}
