package com.herotv.app;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

import java.util.Random;

/**
 * Cinematic background drawn with plain gradients + a few polygons (no bitmaps, no blur,
 * nothing animated): costs almost no memory. The wallpaper is chosen in Settings.
 */
final class BackgroundView extends View {
    static final String[] NAMES = {"بنفسجي سينمائي", "غروب", "جبال", "فضاء", "غابة"};

    private static final int[][] SKY = {
            {0xFF05030F, 0xFF150A38, 0xFF2A0F5C},
            {0xFF140A2A, 0xFF6B1D5C, 0xFFE0693A},
            {0xFF0B1030, 0xFF3B2A7A, 0xFFE46A8E},
            {0xFF02030A, 0xFF0A1440, 0xFF1D3A8A},
            {0xFF04120D, 0xFF0B3B2A, 0xFF165B3F}
    };
    private static final int[] GLOW = {0xFF6D28D9, 0xFFFF8A4C, 0xFFFF7AA8, 0xFF2563EB, 0xFF10B981};
    private static final boolean[] RANGE = {false, true, true, false, false};

    /** Colours used by the wallpaper swatches in Settings. */
    static int[] swatch(int i) { return SKY[i]; }

    private final boolean dim;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private int idx;
    private Shader sky, glow;
    private final Path[] hills = {new Path(), new Path(), new Path()};
    private float[] stars;

    BackgroundView(Context c, int wallpaper, boolean dim) {
        super(c);
        this.idx = clamp(wallpaper);
        this.dim = dim;
    }

    private static int clamp(int i) { return i < 0 || i >= SKY.length ? 0 : i; }

    void setWallpaper(int i) {
        i = clamp(i);
        if (i == idx) return;
        idx = i;
        build(getWidth(), getHeight());
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        build(w, h);
    }

    private void build(int w, int h) {
        if (w <= 0 || h <= 0) return;
        sky = new LinearGradient(0, 0, 0, h, SKY[idx], new float[]{0f, 0.55f, 1f}, Shader.TileMode.CLAMP);
        glow = new RadialGradient(w * 0.78f, h * 0.18f, w * 0.55f,
                new int[]{(GLOW[idx] & 0x00FFFFFF) | 0x77000000, 0x00000000}, null, Shader.TileMode.CLAMP);
        float[] xs = {0f, .12f, .26f, .40f, .55f, .70f, .85f, 1f};
        float[][] ys = {
                {.70f, .60f, .72f, .56f, .70f, .58f, .68f, .64f},
                {.80f, .70f, .82f, .68f, .80f, .70f, .78f, .74f},
                {.90f, .84f, .92f, .82f, .90f, .84f, .90f, .86f}
        };
        for (int k = 0; k < 3; k++) {
            Path path = hills[k];
            path.reset();
            path.moveTo(0, h);
            for (int i = 0; i < xs.length; i++) path.lineTo(xs[i] * w, ys[k][i] * h);
            path.lineTo(w, h);
            path.close();
        }
        if (idx == 3) {
            Random r = new Random(7);
            stars = new float[120];
            for (int i = 0; i < stars.length; i += 3) {
                stars[i] = r.nextFloat() * w;
                stars[i + 1] = r.nextFloat() * h * 0.8f;
                stars[i + 2] = Ui.px(1.5f + r.nextFloat() * 2.5f);
            }
        } else {
            stars = null;
        }
    }

    private static int shade(int c, float f) {
        int r = (int) (((c >> 16) & 0xFF) * (1 - f));
        int g = (int) (((c >> 8) & 0xFF) * (1 - f));
        int b = (int) ((c & 0xFF) * (1 - f));
        return 0xFF000000 | (r << 16) | (g << 8) | b;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth(), h = getHeight();
        if (sky == null) build(w, h);
        if (sky == null) return;
        p.setShader(sky);
        canvas.drawRect(0, 0, w, h, p);
        p.setShader(glow);
        canvas.drawRect(0, 0, w, h, p);
        p.setShader(null);
        if (stars != null) {
            p.setColor(0xCCFFFFFF);
            for (int i = 0; i < stars.length; i += 3) canvas.drawCircle(stars[i], stars[i + 1], stars[i + 2], p);
        }
        if (RANGE[idx]) {
            float[] f = {0.30f, 0.55f, 0.78f};
            for (int k = 0; k < 3; k++) {
                p.setColor(shade(SKY[idx][1], f[k]));
                canvas.drawPath(hills[k], p);
            }
        }
        if (dim) {
            p.setColor(0x66000000);
            canvas.drawRect(0, 0, w, h, p);
        }
    }
}
