package com.herotv.app;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.provider.Settings;

/**
 * Everything that leaves Hero TV goes through here. Rules (from the brief):
 *  - open the ORIGINAL installed app, never a fake copy and never the website in a browser;
 *  - if the app is missing, say so clearly;
 *  - never change system settings automatically (Settings is only opened when the user asks).
 */
final class Launcher {
    private Launcher() {}

    /** Opens an installed app by package name. Returns false if it cannot be launched. */
    static boolean launch(MainActivity a, String pkg) {
        PackageManager pm = a.getPackageManager();
        Intent i = pm.getLeanbackLaunchIntentForPackage(pkg);
        if (i == null) i = pm.getLaunchIntentForPackage(pkg);
        if (i == null) return false;
        try {
            a.markLaunch();
            a.startActivity(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    static void openApp(MainActivity a, Apps.AppInfo app) {
        if (!launch(a, app.pkg)) {
            Dialogs.info(a, "تعذّر فتح التطبيق", "لم نستطع فتح «" + app.label + "». قد يكون التطبيق غير جاهز، جرّب من قائمة تطبيقات التلفزيون الأصلية.");
        }
    }

    /** YouTube: opens the original app. With a query, tries to open YouTube's search inside the app. */
    static void openYouTube(final MainActivity a, final String query) {
        final Apps.AppInfo yt = Apps.youtube(a);
        if (yt == null) {
            Dialogs.youtubeMissing(a);
            return;
        }
        if (query != null && !query.isEmpty()) {
            Intent v = new Intent(Intent.ACTION_VIEW,
                    Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(query)));
            v.setPackage(yt.pkg);            // forces the installed YouTube app, never a browser
            v.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            try {
                a.markLaunch();
                a.startActivity(v);
                return;
            } catch (Exception ignored) {
                // the installed YouTube does not accept search links: fall back below
            }
            Dialogs.choose(a, "افتح YouTube",
                    "سيُفتح تطبيق YouTube الأصلي.\nابحث فيه عن:\n«" + query + "»",
                    new String[]{"فتح YouTube", "إلغاء"},
                    new Runnable[]{new Runnable() {
                        @Override public void run() { launch(a, yt.pkg); }
                    }, null});
            return;
        }
        if (!launch(a, yt.pkg)) Dialogs.youtubeMissing(a);
    }

    static void openItem(MainActivity a, Catalog.Item it) {
        Prefs.pushRecent(it.id);
        openYouTube(a, it.query);
    }

    /** Sends the user to the TV's original home screen. Hero TV is not a HOME app, so this is the stock launcher. */
    static void goToOriginalHome(MainActivity a) {
        Intent h = new Intent(Intent.ACTION_MAIN);
        h.addCategory(Intent.CATEGORY_HOME);
        h.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            a.startActivity(h);
        } catch (Exception e) {
            a.finish();
        }
    }

    /** Opens the TV's own settings screen — only when the user asks for it. */
    static void openSystemSettings(MainActivity a) {
        try {
            a.startActivity(new Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            Dialogs.info(a, "تعذّر فتح الإعدادات", "افتح إعدادات التلفزيون من الواجهة الأصلية.");
        }
    }

    static void openStorePage(MainActivity a, String pkg) {
        try {
            a.markLaunch();
            a.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=" + pkg))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
        } catch (Exception e) {
            Dialogs.info(a, "متجر التطبيقات غير متاح", "ثبّت التطبيق من متجر التطبيقات في الواجهة الأصلية للتلفزيون.");
        }
    }
}
