# Hero TV uses no reflection and no third-party libraries; defaults are enough.
