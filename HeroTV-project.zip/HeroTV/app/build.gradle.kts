plugins {
    id("com.android.application")
}

android {
    namespace = "com.herotv.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.herotv.app"
        minSdk = 24          // Android TV 12 = API 31, we stay compatible with older boxes too
        targetSdk = 34
        versionCode = 1
        versionName = "1.0.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
            // Personal sideload build: signed with the debug key so it installs without a keystore.
            signingConfig = signingConfigs.getByName("debug")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    lint {
        abortOnError = false
    }
}

// Zero third-party dependencies on purpose: smallest APK, lowest RAM use.
tasks.withType<JavaCompile>().configureEach {
    options.encoding = "UTF-8"
}
